import 'package:flutter/material.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_provider_alertsPage.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_provider_viewSchedulePage.dart';
import 'package:mae_assignment/screens/healthcare_provider/viewElderlyPatients.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_providers_dashboard.dart';

import 'package:mae_assignment/theming/custom_themes.dart';

void healthcareProviderBottomNavigationBar(
    BuildContext context, int index, String providerID) {
  switch (index) {
    case 0:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              HealthcareProviderDashboardPage(userID: providerID),
        ),
      );
      break;
    case 1:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SelectElderlyPatientsPage(
              providerID: providerID, destination: 'healthData'),
        ),
      );
      break;
    case 2:
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => SelectElderlyPatientsPage(
                providerID: providerID, destination: 'medicationSchedule')),
      );
      break;
    case 3:
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ViewScheduleAppointmentsPage(
                  providerID: providerID,
                )),
      );
      break;
    case 4:
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => AlertsPage(
                  providerID: providerID,
                )),
      );
      break;
  }
}

class CustomHealthcareProviderNavBar extends StatelessWidget {
  final int currentIndex;
  final double fontSize;
  final Function(int) onTap;

  const CustomHealthcareProviderNavBar({
    Key? key,
    required this.currentIndex,
    required this.fontSize,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      backgroundColor: AppColors.secondary,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home, size: fontSize + 8),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.health_and_safety, size: fontSize + 8),
          label: 'Health Data',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.schedule, size: fontSize + 8),
          label: 'Medication',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.calendar_month, size: fontSize + 8),
          label: 'Schedule',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.notifications, size: fontSize + 8),
          label: 'Alerts',
        ),
      ],
      selectedFontSize: fontSize - 2,
      unselectedFontSize: fontSize - 4,
      onTap: onTap,
    );
  }
}
