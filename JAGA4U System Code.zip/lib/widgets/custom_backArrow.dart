import 'package:flutter/material.dart';

class BackArrowWidget extends StatelessWidget {
  final double size;
  final Color color;

  const BackArrowWidget({
    Key? key,
    required this.size,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back, size: size, color: color),
      onPressed: () {
        Navigator.pop(context); // Navigate back to the previous screen
      },
    );
  }
}