// custom_bottom_nav_bar.dart

import 'package:flutter/material.dart';
import 'package:mae_assignment/providers/selectElderlyPage_provider.dart';
import 'package:mae_assignment/screens/caregiver/caregiverAlertPage.dart';
import 'package:mae_assignment/screens/caregiver/caregiverDashboard.dart';
import 'package:mae_assignment/screens/caregiver/selectElderly.dart';
import 'package:mae_assignment/screens/caregiver/selectHealthcareProvider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:provider/provider.dart';

void handleBottomNavigationTap(BuildContext context, int index, String userID) {
  switch (index) {
    case 0:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CaregiverDashboardPage(userID: userID),
        ),
      );
      break;
    case 1:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChangeNotifierProvider(
            create: (_) => SelectElderlyPageProvider(),
            child: SelectElderlyPage(
              caregiverID: userID,
              destination: 'healthData',
            ),
          ),
        ),
      );
      break;
    case 2:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChangeNotifierProvider(
            create: (_) => SelectElderlyPageProvider(),
            child: SelectElderlyPage(
              caregiverID: userID,
              destination: 'medicationSchedule',
            ),
          ),
        ),
      );
      break;
    case 3:
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => NotificationsScreen(
                  caregiverID: userID,
                )),
      );
      break;
    case 4:
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SelectHealthcareProviderPage(
            caregiverID: userID,
          ),
        ),
      );
      break;
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final double fontSize;
  final Function(int) onTap;

  const CustomBottomNavBar({
    Key? key,
    required this.currentIndex,
    required this.fontSize,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      backgroundColor: AppColors.secondary,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home, size: fontSize + 8),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.health_and_safety, size: fontSize + 8),
          label: 'Health Data',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.schedule, size: fontSize + 8),
          label: 'Medication',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.notifications, size: fontSize + 8),
          label: 'Alerts',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.message, size: fontSize + 8),
          label: 'Messages',
        ),
      ],
      selectedFontSize: fontSize - 2,
      unselectedFontSize: fontSize - 4,
      onTap: onTap,
    );
  }
}
