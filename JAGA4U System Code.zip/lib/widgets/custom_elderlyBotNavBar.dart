import 'package:flutter/material.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_AlertAndNotifications.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_dashboard.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_healthLog.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_reminder.dart';
import 'package:mae_assignment/theming/custom_themes.dart';

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final double fontSize;
  final String userID;

  const CustomBottomNavBar({
    Key? key,
    required this.currentIndex,
    required this.fontSize,
    required this.userID,
  }) : super(key: key);

  // Centralized navigation logic inside the widget
  void _handleBottomNavigationTap(BuildContext context, int index, String userID) {
    // Handle the tap based on the index and navigate accordingly
    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ElderlyDashboardPage(userID: userID),
          ),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ElderlyHealthLogPage(userID: userID),
          ),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ReminderPage(userID: userID),
          ),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ElderlyAlertandnotifications(userID: userID),
          ),
        );
        break;
      // Add more cases as necessary
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    // Icon size calculation, ensuring consistency
    double iconSize = screenWidth * 0.1;

    return BottomNavigationBar(
      currentIndex: currentIndex,
      backgroundColor: AppColors.secondary,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home, size: iconSize),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.health_and_safety, size: iconSize),
          label: 'Health Data',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.alarm, size: iconSize),
          label: 'Reminder',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.notifications, size: iconSize),
          label: 'Alerts',
        ),
      ],
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.placeholder,
      selectedFontSize: fontSize - 2,
      unselectedFontSize: fontSize - 4,
      onTap: (index) => _handleBottomNavigationTap(context, index, userID), // Directly using the method here
    );
  }
}
