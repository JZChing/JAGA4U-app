import 'package:flutter/material.dart';
import 'package:mae_assignment/theming/custom_themes.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String titleImagePath;
  final Color backgroundColor;
  final double elevation;

  CustomAppBar({
    Key? key,
    this.titleImagePath = 'assets/mae emblem.png',
    this.backgroundColor = AppColors.secondary,
    this.elevation = 0, 
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: backgroundColor,
      elevation: elevation,
      automaticallyImplyLeading: false, // Disables the back button
      title: Image.asset(
        titleImagePath,
        height: 60,
      ),
      centerTitle: true,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}