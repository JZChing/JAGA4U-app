import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mae_assignment/models/user.dart';

//
class UserRepository {
  final CollectionReference usersRef =
      FirebaseFirestore.instance.collection('users');

  // Function to get user's role from a document
  String getUserRole(DocumentSnapshot userDoc) {
    return userDoc['role'];
  }
  
  Future<DocumentSnapshot> getUserByUsername(String username) async {
    final userSnapshot =
        await usersRef.where('username', isEqualTo: username).limit(1).get();

    if (userSnapshot.docs.isNotEmpty) {
      return userSnapshot.docs.first;
    } else {
      throw Exception("User  not found");
    }
  }

  Future<void> addAssociatedHealthcareProvider(
      String caregiverID, String healthcareProviderID, String username) async {
    await usersRef
        .doc(caregiverID)
        .collection('associatedHealthcareProviders')
        .doc(healthcareProviderID)
        .set({
      'username': username,
      'userID': healthcareProviderID,
    });
  }

  Future<void> deleteAssociatedElderlyUser(
      String caregiverID, String elderlyUserID) async {
    await usersRef
        .doc(caregiverID)
        .collection('associatedElderlyUsers')
        .doc(elderlyUserID)
        .delete();
  }

  Future<void> deleteAssociatedHealthcareProviders(
      String caregiverID, String HealthcareProviderID) async {
    await usersRef
        .doc(caregiverID)
        .collection('associatedHealthcareProviders')
        .doc(HealthcareProviderID)
        .delete();
  }

  Future<void> addAssociatedElderlyUser(
      String caregiverID, String elderlyUserID, String username) async {
    await usersRef
        .doc(caregiverID)
        .collection('associatedElderlyUsers')
        .doc(elderlyUserID)
        .set({
      'username': username,
      'userID': elderlyUserID,
    });
  }

  Future<void> updateElderlyUserWithCaregiverID(
      String elderlyUserID, String caregiverID) async {
    await usersRef.doc(elderlyUserID).update({
      'caregiverID': FieldValue.arrayUnion([caregiverID])
    });
  }

  Future<void> removeCaregiverFromElderlyUser(
      String elderlyUserID, String caregiverID) async {
    await usersRef.doc(elderlyUserID).update({
      'caregiverID': FieldValue.arrayRemove([caregiverID])
    });
  }

  Future<void> updateHealthcareProviderWithCaregiverID(
      String healthcareProviderID, String caregiverID) async {
    await usersRef.doc(healthcareProviderID).update({
      'caregiverID': FieldValue.arrayUnion([caregiverID])
    });
  }

  Future<void> removeCaregiverFromHealthcareProvider(
      String HealthcareProviderID, String caregiverID) async {
    await usersRef.doc(HealthcareProviderID).update({
      'caregiverID': FieldValue.arrayRemove([caregiverID])
    });
  }

  Stream<List<Map<String, String>>> streamHealthcareProviders(
      String caregiverID) {
    return usersRef
        .doc(caregiverID)
        .collection('associatedHealthcareProviders')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return {
          'userID': doc['userID'] as String,
          'username': doc['username'] as String,
        };
      }).toList();
    });
  }

  Stream<List<Map<String, String>>> streamAssociatedElderlyUsers(
      String caregiverID) {
    return usersRef
        .doc(caregiverID)
        .collection('associatedElderlyUsers')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return {
          'userID': doc['userID'] as String,
          'username': doc['username'] as String,
        };
      }).toList();
    });
  }

  // Check if the username is unique
  Future<bool> isUsernameUnique(String username) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('username', isEqualTo: username)
        .get();

    return querySnapshot
        .docs.isEmpty; // If no document is found, the username is unique
  }

  // Register a new user with Firebase Authentication and Firestore
  Future<void> registerUser(UserData newUser) async {
    // Create a new user in Firebase Authentication
    UserCredential userCredential =
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: newUser.email,
      password: newUser.password,
    );

    // Get the unique user ID from Firebase Authentication
    String userID = userCredential.user!.uid;

    // Update the userID in newUser object
    newUser = UserData(
      userID: userID, // Assign generated userID here
      username: newUser.username,
      password: newUser.password,
      email: newUser.email,
      role: newUser.role,
      contactInfo: newUser.contactInfo,
      profileImage: newUser.profileImage,
      createdAt: newUser.createdAt,
    );

    // Save user info in Firestore
    await usersRef.doc(userID).set(newUser.toJson());
  }

  // Retrieve a user by ID
  Future<UserData?> getUserByID(String userID) async {
    try {
      if (userID.isEmpty) {
        throw ArgumentError("User ID cannot be empty.");
      }
      final doc = await usersRef.doc(userID).get();
      if (doc.exists) {
        return UserData.fromFirestore(doc);
      } else {
        print("User not found for ID: $userID");
        return null;
      }
    } catch (e) {
      print("Failed to retrieve user by ID: $e");
      throw Exception("Error retrieving user.");
    }
  }

  // Update a user in Firestore
  Future<void> updateUser(UserData user) async {
    try {
      if (user.userID.isEmpty) {
        throw ArgumentError("User ID cannot be empty.");
      }
      await usersRef.doc(user.userID).update(user.toJson());
    } catch (e) {
      print("Failed to update user: $e");
      throw Exception("Error updating user.");
    }
  }

  Future<List<Map<String, dynamic>>> fetchHealthcareProviders() async {
    try {
      QuerySnapshot querySnapshot =
          await usersRef.where('role', isEqualTo: 'Healthcare Provider').get();

      return querySnapshot.docs.map((doc) {
        return {
          'id': doc.id,
          ...doc.data() as Map<String, dynamic>,
        };
      }).toList();
    } catch (e) {
      print("Failed to fetch healthcare providers: $e");
      throw Exception("Failed to fetch healthcare providers.");
    }
  }

  Future<String?> getElderlyUserNameByID(String elderlyUserID) async {
    try {
      final doc = await usersRef.doc(elderlyUserID).get();
      if (doc.exists) {
        return doc['username'] as String?;
      } else {
        print("Elderly user not found for ID: $elderlyUserID");
        return null;
      }
    } catch (e) {
      print("Error fetching elderly user name: $e");
      return null;
    }
  }

  // Fetch associated elderly user IDs for a given caregiver
  Future<List<String>> fetchAssociatedElderlyUserIDs(String caregiverID) async {
    try {
      QuerySnapshot associatedUsersSnapshot = await usersRef
          .doc(caregiverID)
          .collection('associatedElderlyUsers')
          .get();

      List<String> elderlyUserIDs =
          associatedUsersSnapshot.docs.map((doc) => doc.id).toList();

      return elderlyUserIDs;
    } catch (e) {
      print("Error fetching associated elderly users: $e");
      return [];
    }
  }

  Stream<List<Map<String, String>>> streamCaregivers(String providerID) {
    final usersRef = FirebaseFirestore.instance.collection('users');

    return usersRef.doc(providerID).snapshots().asyncMap((providerDoc) async {
      // Check if the document exists and has the caregiverID field
      if (!providerDoc.exists || !providerDoc.data()!.containsKey('caregiverID')) {
        return [];
      }

      List<String> caregiverIDs = List<String>.from(providerDoc['caregiverID']);
      List<Map<String, String>> caregivers = [];

      for (String caregiverID in caregiverIDs) {
        final caregiverDoc = await usersRef.doc(caregiverID).get();
        if (caregiverDoc.exists) {
          caregivers.add({
            'userID': caregiverDoc.id,
            'username': caregiverDoc['username'] as String,
          });
        }
      }

      return caregivers;
    });
  }
}
