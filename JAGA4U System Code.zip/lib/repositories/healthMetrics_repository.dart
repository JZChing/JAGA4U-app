import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/health_metrics.dart';

class HealthMetricsRepository {
  final CollectionReference _healthMetricsCollection =
      FirebaseFirestore.instance.collection('HealthMetrics');
// Fetch health metrics for a specific elderly user
  Future<List<HealthMetrics>> fetchHealthData(String userID) async {
    try {
      final snapshot = await _healthMetricsCollection
          .where('elderlyUserID', isEqualTo: userID)
          .get();

      return snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return HealthMetrics(
          dateTime:
              data['dateTime'] ?? DateTime.now(), // Provide a default value
          bloodPressure:
              data['bloodPressure'] ?? 0.0, // Provide a default value
          pulseRate: data['pulseRate'] ?? 0.0, // Provide a default value
          metricID: doc.id,
          elderlyUserID: userID,
          emergencyStatus:
              data['emergencyStatus'] ?? false, // Default to false if null
        );
      }).toList();
    } catch (e) {
      print("Error fetching health data: $e");
      throw Exception("Error fetching health data.");
    }
  }

  // Log new health data entry
  Future<void> logHealthData(String userID, String bloodPressure,
      String pulseRate, bool isEmergency) async {
    try {
      String healthMetricsID = _healthMetricsCollection.doc().id;

      await _healthMetricsCollection.doc(healthMetricsID).set({
        'healthMetricsID': healthMetricsID,
        'elderlyUserID': userID,
        'dateTime': DateTime.now(),
        'bloodPressure': double.parse(bloodPressure),
        'pulseRate': double.parse(pulseRate),
        'emergencyStatus': isEmergency,
      });
    } catch (e) {
      print("Error logging health data: $e");
      throw Exception("Error logging health data.");
    }
  }
}
