import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/chat.dart';

class ChatRepository {
  final CollectionReference _chatCollection = FirebaseFirestore.instance.collection('chats');

  // Add a new chat entry
  Future<void> addChat(Chat chat) async {
    try {
      if (chat.chatID.isEmpty) {
        throw ArgumentError('Chat ID cannot be empty.');
      }
      await _chatCollection.doc(chat.chatID).set(chat.toJson());
    } catch (e) {
      print('Failed to add chat: $e');
      throw Exception('Error adding chat.');
    }
  }

  // Retrieve a single chat by ID
  Future<Chat?> getChatById(String chatID) async {
    try {
      if (chatID.isEmpty) {
        throw ArgumentError('Chat ID cannot be empty.');
      }
      DocumentSnapshot doc = await _chatCollection.doc(chatID).get();
      if (doc.exists) {
        return Chat.fromFirestore(doc);
      } else {
        print('Chat not found for ID: $chatID');
        return null;
      }
    } catch (e) {
      print('Failed to retrieve chat: $e');
      throw Exception('Error retrieving chat.');
    }
  }

  // Retrieve all chats for a participant
  Stream<List<Chat>> getChatsByParticipant(String userID) {
    try {
      if (userID.isEmpty) {
        throw ArgumentError('User ID cannot be empty.');
      }
      return _chatCollection
          .where('participants', arrayContains: userID)
          .snapshots()
          .map((snapshot) =>
              snapshot.docs.map((doc) => Chat.fromFirestore(doc)).toList());
    } catch (e) {
      print('Failed to retrieve chats by participant: $e');
      throw Exception('Error retrieving chats.');
    }
  }

  // Add a message to a chat
  Future<void> addMessage(String chatID, String senderID, String recipientID, String messageText) async {
    try {
      if (chatID.isEmpty || senderID.isEmpty || recipientID.isEmpty || messageText.isEmpty) {
        throw ArgumentError('Chat ID, Sender ID, Recipient ID, and Message Text cannot be empty.');
      }

      final messageID = _chatCollection.doc(chatID).collection('messages').doc().id;
      final messageRef = _chatCollection.doc(chatID).collection('messages').doc(messageID);

      await messageRef.set({
        'senderID': senderID,
        'recipientID': recipientID,
        'messageText': messageText,
        'time': Timestamp.now(),
        'isRead': false,
      });

      // Update the last message and time in the Chat document
      await _chatCollection.doc(chatID).update({
        'lastMessage': messageText,
        'lastMessageTime': Timestamp.now(),
      });
    } catch (e) {
      print('Failed to add message: $e');
      throw Exception('Error adding message.');
    }
  }

  // Retrieve all messages from a chat's subcollection
  Stream<List<Map<String, dynamic>>> getMessages(String chatID) {
    try {
      if (chatID.isEmpty) {
        throw ArgumentError('Chat ID cannot be empty.');
      }
      return _chatCollection
          .doc(chatID)
          .collection('messages')
          .orderBy('time')
          .snapshots()
          .map((snapshot) =>
              snapshot.docs.map((doc) => doc.data()).toList());
    } catch (e) {
      print('Failed to retrieve messages: $e');
      throw Exception('Error retrieving messages.');
    }
  }

  // Delete a chat
  Future<void> deleteChat(String chatID) async {
    try {
      if (chatID.isEmpty) {
        throw ArgumentError('Chat ID cannot be empty.');
      }
      await _chatCollection.doc(chatID).delete();
    } catch (e) {
      print('Failed to delete chat: $e');
      throw Exception('Error deleting chat.');
    }
  }
}

