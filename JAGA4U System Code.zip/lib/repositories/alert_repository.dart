import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/alert.dart';

class AlertRepository {
  final CollectionReference _alertCollection = FirebaseFirestore.instance.collection('alerts');

  // Add a new alert entry
  Future<void> addAlert(Alert alert) async {
    try {
      if (alert.alertID.isEmpty) {
        throw ArgumentError('Alert ID cannot be empty.');
      }
      await _alertCollection.doc(alert.alertID).set(alert.toJson());
    } catch (e) {
      print('Failed to add alert: $e');
      throw Exception('Error adding alert.');
    }
  }



  // Retrieve all alerts for a specific healthcare provider
  Stream<List<Alert>> getAlertsForHealthcareProvider(String providerID) {
    try {
      if (providerID.isEmpty) {
        throw ArgumentError('Provider ID cannot be empty.');
      }
      return _alertCollection
          .where('healthcareProviderIDs', arrayContains: providerID)
          .snapshots()
          .map((snapshot) => snapshot.docs.map((doc) => Alert.fromFirestore(doc)).toList());
    } catch (e) {
      print('Failed to retrieve alerts for healthcare provider: $e');
      return Stream.error('Error retrieving alerts for healthcare provider.');
    }
  }

  // Retrieve alerts for a specific elderly user
  Stream<List<Alert>> fetchAlertsForElderly(String elderlyID) {
    try {
      if (elderlyID.isEmpty) {
        throw ArgumentError('Elderly ID cannot be empty.');
      }
      return _alertCollection
          .where('elderlyID', isEqualTo: elderlyID)
          .snapshots()
          .map((snapshot) => snapshot.docs.map((doc) => Alert.fromFirestore(doc)).toList());
    } catch (e) {
      print('Failed to retrieve alerts for elderly: $e');
      return Stream.error('Error retrieving alerts for elderly.');
    }
  }

  // Update an alert's status
  Future<void> updateAlertStatus(String alertID, String newStatus) async {
    try {
      if (alertID.isEmpty) {
        throw ArgumentError('Alert ID cannot be empty.');
      }
      if (newStatus.isEmpty) {
        throw ArgumentError('Status cannot be empty.');
      }
      await _alertCollection.doc(alertID).update({'alertStatus': newStatus});
    } catch (e) {
      print('Failed to update alert status: $e');
      throw Exception('Error updating alert status.');
    }
  }

  // Delete an alert
  Future<void> deleteAlert(String alertID) async {
    try {
      if (alertID.isEmpty) {
        throw ArgumentError('Alert ID cannot be empty.');
      }
      await _alertCollection.doc(alertID).delete();
    } catch (e) {
      print('Failed to delete alert: $e');
      throw Exception('Error deleting alert.');
    }
  }

  Future<List<Alert>> fetchAlertsForCaregiver(String caregiverID) async {
    try {
      QuerySnapshot alertSnapshot = await _alertCollection
          .where('caregiverIDs', arrayContains: caregiverID)
          .get();
      return alertSnapshot.docs.map((doc) => Alert.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error retrieving alerts for caregiver: $e');
      return [];
    }
  }

  Future<List<Alert>> fetchAlertsForProvider(String ProviderID) async {
    try {
      QuerySnapshot alertSnapshot = await _alertCollection
          .where('healthcareProviderIDs', arrayContains: ProviderID)
          .get();
      return alertSnapshot.docs.map((doc) => Alert.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error retrieving alerts for healthcare provider: $e');
      return [];
    }
  }

  Future<void> deleteAlertForCaregiver(String alertID) async {
    try {
      await _alertCollection.doc(alertID).delete();
    } catch (e) {
      print('Error deleting alert: $e');
      throw e;
    }
  }
}
