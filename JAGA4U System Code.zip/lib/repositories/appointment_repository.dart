import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mae_assignment/models/appointment.dart';
import 'package:mae_assignment/repositories/user_repository.dart';

class AppointmentRepository extends ChangeNotifier {
  final CollectionReference _appointmentCollection =
      FirebaseFirestore.instance.collection('appointments');
  final UserRepository _userRepository = UserRepository();

  // Schedule a new appointment
  Future<void> scheduleAppointment(
      String elderlyID, String providerID, DateTime dateTime) async {
    try {
      if (providerID.isEmpty || elderlyID.isEmpty) {
        throw ArgumentError('Elderly ID and Provider ID cannot be empty.');
      }

      String appointmentID = _appointmentCollection.doc().id;

      await _appointmentCollection.doc(appointmentID).set({
        'appointmentID': appointmentID,
        'elderlyID': elderlyID,
        'healthCareID': providerID,
        'appointmentDateTime': Timestamp.fromDate(dateTime),
        'status': 'scheduled',
      });
    } catch (e) {
      print('Failed to schedule appointment: $e');
      throw Exception('Error scheduling appointment.');
    }
  }

  // Update an appointment's status
  Future<void> updateAppointmentStatus(
      String appointmentID, String newStatus) async {
    try {
      if (appointmentID.isEmpty) {
        throw ArgumentError('Appointment ID cannot be empty.');
      }
      if (newStatus.isEmpty) {
        throw ArgumentError('Status cannot be empty.');
      }
      await _appointmentCollection
          .doc(appointmentID)
          .update({'status': newStatus});
    } catch (e) {
      print('Failed to update appointment status: $e');
      throw Exception('Error updating appointment status.');
    }
  }

  // Delete an appointment
  Future<void> deleteAppointment(String appointmentID) async {
    try {
      if (appointmentID.isEmpty) {
        throw ArgumentError('Appointment ID cannot be empty.');
      }
      await _appointmentCollection.doc(appointmentID).delete();
    } catch (e) {
      print('Failed to delete appointment: $e');
      throw Exception('Error deleting appointment.');
    }
  }

    // Stream to get appointments along with elderly usernames
  Stream<List<Map<String, dynamic>>> getAppointmentsWithElderlyUsername(String userID) async* {
    await for (final snapshot in _appointmentCollection
        .where('healthCareID', isEqualTo: userID)
        .snapshots()) {
      List<Map<String, dynamic>> appointmentsWithUsername = [];
      
      for (final doc in snapshot.docs) {
        final appointment = Appointment.fromFirestore(doc);
        
        // Fetch elderly username from users collection using elderlyID
        final elderlyUsername = await _userRepository.getElderlyUserNameByID(appointment.elderlyID);
        
        appointmentsWithUsername.add({
          'appointment': appointment,
          'elderlyUsername': elderlyUsername ?? 'Unknown',
        });
      }
      yield appointmentsWithUsername;
    }
  }
}
