import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/medication.dart';

class MedicationRepository {
  final CollectionReference medicationsRef =
      FirebaseFirestore.instance.collection('medications');
  
  // Fetch medication stream for a specific elderly user with a scheduled status
  Stream<List<Medication>> fetchMedicationsStream(String elderlyUserID) {
    return medicationsRef
        .where('elderlyUserID', isEqualTo: elderlyUserID)
        .where('medicationStatus', isEqualTo: 'Scheduled')
        .snapshots()
        .map((querySnapshot) {
          return querySnapshot.docs.map((doc) {
            DateTime medicationDateTime = (doc['dateTime'] as Timestamp).toDate();
            return Medication(
              medicationID: doc.id,
              medicationType: doc['medicationType'] ?? 'Unknown',
              dosage: doc['dosage'] ?? 'N/A',
              medicationStatus: doc['medicationStatus'] ?? 'Scheduled',
              dateTime: medicationDateTime,
              elderlyUserID: doc['elderlyUserID'],
            );
          }).toList();
        });
  }

  Future<List<Medication>> fetchMedicationsForUserToday(String userID) async {
    try {
      DateTime today = DateTime.now();
      QuerySnapshot querySnapshot = await medicationsRef
          .where('elderlyUserID', isEqualTo: userID)
          .get();

      return querySnapshot.docs.map((doc) {
        if (doc['dateTime'] != null) {
          DateTime medicationDateTime = (doc['dateTime'] as Timestamp).toDate();
          DateTime medicationDate = DateTime(medicationDateTime.year, medicationDateTime.month, medicationDateTime.day);

          if (medicationDate.isAtSameMomentAs(DateTime(today.year, today.month, today.day))) {
            return Medication(
              medicationID: doc.id,
              medicationType: doc['medicationType'] ?? 'Unknown',
              dosage: doc['dosage'] ?? 'N/A',
              medicationStatus: doc['medicationStatus'] ?? 'pending',
              dateTime: medicationDateTime,
              elderlyUserID: doc['elderlyUserID'],
            );
          }
        }
        return null;
      }).whereType<Medication>().toList();
    } catch (e) {
      print("Error fetching medications: $e");
      return [];
    }
  }

  // Add a new medication to Firestore
  Future<DocumentReference> addMedication(Medication medication) async {
    return await medicationsRef.add(medication.toJson());
  }

  // Retrieve a medication by ID
  Future<Medication?> getMedicationByID(String medicationID) async {
    try {
      if (medicationID.isEmpty) {
        throw ArgumentError("Medication ID cannot be empty.");
      }
      final doc = await medicationsRef.doc(medicationID).get();
      if (doc.exists) {
        return Medication.fromFirestore(doc);
      } else {
        print("Medication not found for ID: $medicationID");
        return null;
      }
    } catch (e) {
      print("Failed to retrieve medication by ID: $e");
      throw Exception("Error retrieving medication.");
    }
  }

  // Update the medicationID field after adding a medication
  Future<void> updateMedicationID(String medicationID) async {
    await medicationsRef.doc(medicationID).update({'medicationID': medicationID});
  }

  // Delete a medication from Firestore
  Future<void> deleteMedication(String medicationID) async {
    try {
      if (medicationID.isEmpty) {
        throw ArgumentError("Medication ID cannot be empty.");
      }
      await medicationsRef.doc(medicationID).delete();
    } catch (e) {
      print("Failed to delete medication: $e");
      throw Exception("Error deleting medication.");
    }
  }

// Retrieve medications for a specific elderly user by medication ID
  Future<List<Medication>> getMedicationsByElderlyUserAndMedicationID(
      String elderlyUserID, String medicationID) async {
    try {
      if (elderlyUserID.isEmpty || medicationID.isEmpty) {
        throw ArgumentError(
            "Both Elderly User ID and Medication ID cannot be empty.");
      }
      final snapshot = await medicationsRef
          .where('elderlyUserID', isEqualTo: elderlyUserID)
          .where('medicationID', isEqualTo: medicationID)
          .get();
      return snapshot.docs.map((doc) => Medication.fromFirestore(doc)).toList();
    } catch (e) {
      print(
          "Failed to retrieve medications for elderly user and medication ID: $e");
      throw Exception(
          "Error retrieving medications for elderly user and medication ID.");
    }
  }
}
