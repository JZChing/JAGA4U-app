import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/reminder.dart';

class ReminderRepository {
  final CollectionReference remindersRef = FirebaseFirestore.instance.collection('reminders');

  // Add a new reminder to Firestore
  Future<DocumentReference> addReminder(Reminder reminder) async {
    try {
      return await remindersRef.add(reminder.toJson());
    } catch (e) {
      print("Error adding reminder: $e");
      rethrow;
    }
  }

  Future<void> deleteReminderByMedicationID(String medicationID) async {
    try {
      final reminderSnapshot = await remindersRef
          .where('medicationID', isEqualTo: medicationID)
          .get();

      for (var doc in reminderSnapshot.docs) {
        await doc.reference.delete();
      }
    } catch (e) {
      print("Error deleting reminder: $e");
    }
  }

  // Update the reminderID field after adding a reminder
  Future<void> updateReminderID(String reminderID) async {
    await remindersRef.doc(reminderID).update({'reminderID': reminderID});
  }

  // Retrieve reminders for a specific elderly user
  Future<List<Reminder>> getRemindersByElderlyUser(String elderlyUserID) async {
    try {
      if (elderlyUserID.isEmpty) {
        throw ArgumentError("Elderly User ID cannot be empty.");
      }
      final snapshot = await remindersRef.where('elderlyUserID', isEqualTo: elderlyUserID).get();
      return snapshot.docs.map((doc) => Reminder.fromFirestore(doc)).toList();
    } catch (e) {
      print("Failed to retrieve reminders for elderly user: $e");
      throw Exception("Error retrieving reminders for elderly user.");
    }
  }
}

