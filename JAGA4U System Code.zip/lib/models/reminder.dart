import 'package:cloud_firestore/cloud_firestore.dart';

class Reminder {
  final String reminderID;
  final String elderlyUserID;
  final String medicationID;
  final String medicationType;
  String reminderStatus;
  final Timestamp datetime;
  String delayAlert;

  Reminder({
    required this.reminderID,
    required this.elderlyUserID,
    required this.medicationID,
    required this.medicationType,
    required this.reminderStatus,
    required this.datetime,
    this.delayAlert = '0',
  });

  factory Reminder.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Reminder(
      reminderID: data['reminderID'] ?? '',
      elderlyUserID: data['elderlyUserID'] ?? '',
      medicationID: data['medicationID'] ?? '',
      medicationType: data['medicationType'] ?? '',
      reminderStatus: data['reminderStatus'] ?? '-',
      datetime: data['datetime'] ?? Timestamp.now(),
      delayAlert: data['delayAlert'] ?? '0',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'reminderID': reminderID,
      'elderlyUserID': elderlyUserID,
      'medicationID': medicationID,
      'medicationType': medicationType,
      'reminderStatus': reminderStatus,
      'datetime': datetime,
      'delayAlert': delayAlert,
    };
  }

  // Check if reminder is due
  bool isDue() {
    DateTime now = DateTime.now();
    return datetime.toDate().isAtSameMomentAs(now) || datetime.toDate().isBefore(now);
  }

  // Time remaining before reminder is due
  Duration timeRemaining() {
    return datetime.toDate().difference(DateTime.now());
  }

  // Check if the reminder expired after 5 minutes
  bool isExpired() {
    DateTime reminderDateTime = datetime.toDate();
    DateTime currentDateTime = DateTime.now();

    // Check if the reminder is more than 5 minutes overdue
    Duration difference = currentDateTime.difference(reminderDateTime);
    return difference.inMinutes > 5;
  }
}
