import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/constants/placeholderURL.dart';

class UserData {
  final String userID;
  final String username;
  final String password;
  final String email;
  final String role; // elderly, caregiver, healthcare provider
  final String contactInfo;
  final String profileImage;
  final Timestamp createdAt;

  UserData({
    required this.userID,
    required this.username,
    required this.password,
    required this.email,
    required this.role,
    required this.contactInfo,
    this.profileImage = "", // Default empty string or placeholder image
    required this.createdAt,
  });

  // Factory constructor to create User instance from Firestore document
  factory UserData.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return UserData(
      userID: data['userID'] ?? '',
      username: data['username'] ?? '',
      password: data['password'] ?? '',
      email: data['email'] ?? '',
      role: data['role'] ?? 'unknown',
      contactInfo: data['contactInfo'] ?? '',
      profileImage: data['profileImage'] != "userPlaceholder" ? data['profileImage'] : userPlaceholder,
      createdAt: data['createdAt'] ?? Timestamp.now(),
    );
  }

  // Method to convert User instance to JSON for Firestore
  Map<String, dynamic> toJson() {
    return {
      'userID': userID,
      'username': username,
      'password': password, // Again, consider hashing before storing
      'email': email,
      'role': role,
      'contactInfo': contactInfo,
      'profileImage': profileImage,
      'createdAt': createdAt,
    };
  }
}