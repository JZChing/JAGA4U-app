import 'package:cloud_firestore/cloud_firestore.dart';

class Appointment {
  final String appointmentID; // Unique identifier for the appointment
  final String elderlyID; // The ID of the user making the appointment
  final String healthCareID; // The ID of the healthcare provider
  final Timestamp appointmentDateTime; // The date and time of the appointment
  final String status; // Status of the appointment (e.g., 'scheduled', 'completed', 'canceled')

  Appointment({
    required this.appointmentID,
    required this.elderlyID,
    required this.healthCareID,
    required this.appointmentDateTime,
    required this.status,
  });

  // Factory method to create an Appointment from Firestore document
  factory Appointment.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Appointment(
      appointmentID: data['appointmentID'] ?? '',
      elderlyID: data['elderlyID'] ?? '',
      healthCareID: data['healthCareID'] ?? '',
      appointmentDateTime: data['appointmentDateTime'] ?? Timestamp.now(),
      status: data['status'] ?? 'scheduled',
    );
  }

  // Method to convert an Appointment instance to a JSON object
  Map<String, dynamic> toJson() {
    return {
      'appointmentID': appointmentID,
      'elderlyID': elderlyID,
      'healthCareID': healthCareID,
      'appointmentDateTime': appointmentDateTime,
      'status': status,
    };
  }
}
