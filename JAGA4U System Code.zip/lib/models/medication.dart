import 'package:cloud_firestore/cloud_firestore.dart';

class Medication {
  final String medicationID;
  final String medicationType;
  final String dosage;
  final DateTime dateTime;
  final String medicationStatus;
  final String elderlyUserID;

  Medication({
    required this.medicationID,
    required this.medicationType,
    required this.dosage,
    required this.dateTime,
    required this.medicationStatus,
    required this.elderlyUserID,
  });

  
  // Define the copyWith method
  Medication copyWith({
    String? medicationID,
    String? medicationType,
    String? dosage,
    DateTime? dateTime,
    String? medicationStatus,
    String? elderlyUserID,
  }) {
    return Medication(
      medicationID: medicationID ?? this.medicationID,
      medicationType: medicationType ?? this.medicationType,
      dosage: dosage ?? this.dosage,
      dateTime: dateTime ?? this.dateTime,
      medicationStatus: medicationStatus ?? this.medicationStatus,
      elderlyUserID: elderlyUserID ?? this.elderlyUserID,
    );
  }

  factory Medication.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Medication(
      medicationID: data['medicationID'] ?? '',
      medicationType: data['medicationType'] ?? '',
      dosage: data['dosage'] ?? '',
      dateTime: (data['dateTime'] as Timestamp).toDate(),
      medicationStatus: data['medicationStatus'] ?? '',
      elderlyUserID: data['elderlyUserID'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'medicationID': medicationID,
      'medicationType': medicationType,
      'dosage': dosage,
      'dateTime': dateTime,
      'medicationStatus': medicationStatus,
      'elderlyUserID': elderlyUserID,
    };
  }
}
