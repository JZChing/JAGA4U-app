import 'package:cloud_firestore/cloud_firestore.dart';

class Message {
  String senderID;
  String recipientID;
  String messageText;
  Timestamp time;
  bool isRead;

  Message({
    required this.senderID,
    required this.recipientID,
    required this.messageText,
    required this.time,
    required this.isRead,
  });

  // From Firestore
  factory Message.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Message(
      senderID: data['senderID'],
      recipientID: data['recipientID'],
      messageText: data['messageText'],
      time: data['time'] ?? Timestamp.now(),
      isRead: data['isRead'] ?? false,
    );
  }

  // To Firestore
  Map<String, dynamic> toFirestore() {
    return {
      'senderID': senderID,
      'recipientID': recipientID,
      'messageText': messageText,
      'time': time,
      'isRead': isRead,
    };
  }
}
