import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/user.dart';

class Alert {
  final String alertID;
  final Timestamp alertTime;
  final String alertStatus;
  final List<String> caregiverIDs; // List of caregiver user IDs
  final String elderlyID; // Elderly user ID
  final List<String> healthcareProviderIDs; // List of healthcare provider user IDs
  final List<String> medicationID; // Medication ID(s)

  Alert({
    required this.alertID,
    required this.alertTime,
    required this.alertStatus,
    required this.caregiverIDs,
    required this.elderlyID,
    required this.healthcareProviderIDs,
    required this.medicationID,
  });

  factory Alert.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

    return Alert(
      alertID: doc.id,
      alertTime: data['alertTime'] ?? Timestamp.now(),
      alertStatus: data['alertStatus'] ?? 'unread',
      caregiverIDs: _convertToList(data['caregiverIDs']),
      elderlyID: data['elderlyID'] ?? '',
      healthcareProviderIDs: _convertToList(data['healthcareProviderIDs']),
      medicationID: _convertToList(data['medicationID']),
    );
  }

  static List<String> _convertToList(dynamic field) {
    if (field is Iterable) {
      return List<String>.from(field);
    } else if (field is String) {
      return [field];
    } else {
      return [];
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'alertID': alertID,
      'alertTime': alertTime,
      'alertStatus': alertStatus,
      'caregiverIDs': caregiverIDs,
      'elderlyID': elderlyID,
      'healthcareProviderIDs': healthcareProviderIDs,
      'medicationID': medicationID,
    };
  }

  // Optimized function to get user data for a list of user IDs
  Future<List<UserData>> getUserData(List<String> userIDs) async {
    if (userIDs.isEmpty) return [];

    final userRef = FirebaseFirestore.instance.collection('users');
    final querySnapshot = await userRef.where(FieldPath.documentId, whereIn: userIDs).get();

    return querySnapshot.docs.map((doc) => UserData.fromFirestore(doc)).toList();
  }
}
