import 'package:cloud_firestore/cloud_firestore.dart';

class HealthMetrics {
  final String metricID;
  final String elderlyUserID;
  final double bloodPressure;
  final double pulseRate;
  final Timestamp dateTime;
  final bool emergencyStatus;

  HealthMetrics({
    required this.metricID,
    required this.elderlyUserID,
    required this.bloodPressure,
    required this.pulseRate,
    required this.dateTime,
    required this.emergencyStatus,
  });

    @override
  String toString() {
    return 'HealthMetrics(dateTime: $dateTime, bloodPressure: $bloodPressure, pulseRate: $pulseRate)';
  }

  factory HealthMetrics.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return HealthMetrics(
      metricID: data['metricID'] ?? '',
      elderlyUserID: data['elderlyUserID'] ?? '',
      bloodPressure: (data['bloodPressure'] ?? 0).toDouble(),
      pulseRate: (data['pulseRate'] ?? 0).toDouble(),
      dateTime: data['dateTime'] ?? Timestamp.now(),
      emergencyStatus: data['emergencyStatus'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'metricID': metricID,
      'elderlyUserID': elderlyUserID,
      'bloodPressure': bloodPressure,
      'pulseRate': pulseRate,
      'dateTime': dateTime,
      'emergencyStatus': emergencyStatus,
    };
  }
}
