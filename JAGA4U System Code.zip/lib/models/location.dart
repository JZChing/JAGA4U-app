class LocationModel {
  final double latitude;
  final double longitude;
  final DateTime timestamp;
  final String elderlyID;

  LocationModel({
    required this.latitude,
    required this.longitude,
    required this.timestamp,
    required this.elderlyID
  });

  // Convert model to Firestore-friendly map
  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'timestamp': timestamp,
      'elderlyID': elderlyID,
    };
  }

  // Create model from Firestore document snapshot
  factory LocationModel.fromMap(Map<String, dynamic> map) {
    return LocationModel(
      latitude: map['latitude'],
      longitude: map['longitude'],
      timestamp: map['timestamp'].toDate(),
      elderlyID: map['elderlyID'],
    );
  }
}
