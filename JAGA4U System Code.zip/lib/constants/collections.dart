import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseFirestore _firestore = FirebaseFirestore.instance;

// Define collection references for main entities
final CollectionReference userCollection = _firestore.collection('users');
final CollectionReference healthMetricsCollection = _firestore.collection('healthMetrics');
final CollectionReference reminderCollection = _firestore.collection('reminders');
final CollectionReference medicationCollection = _firestore.collection('medications');
final CollectionReference alertCollection = _firestore.collection('alerts');
final CollectionReference chatCollection = _firestore.collection('chats');

// Subcollection names for User document subcollections
const caregiverSubCollection = 'caregivers';
const healthcareProviderSubCollection = 'healthcareProviders';
const elderlyUserSubCollection = 'elderlyUsers';

// Subcollection names for Chats
const messagesSubCollection = 'messages';

