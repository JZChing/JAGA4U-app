import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF3498db); // bright blue
  static const Color secondary = Color(0xFFa9dfbf); // mint green
  static const Color tertiary = Color(0xFFe74c3c); // coral/red - use sparingly for warnings/important info
  static const Color placeholder = Colors.grey; // dark gray
  static const Color background = Color(0xFFf2f4f4); // light gray/white
}

class AppTextStyles {
  static final TextStyle topAppBar = GoogleFonts.lato(
      fontSize: 24.0, fontWeight: FontWeight.bold, color: Colors.black);

  static final TextStyle bottomAppBar = GoogleFonts.lato(
      fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black);

  static const TextStyle bodyText1 =
      TextStyle(fontSize: 18, color: AppColors.secondary);

  static const TextStyle placeholderText =
      TextStyle(fontSize: 18, color: AppColors.placeholder);

  static const TextStyle buttonText =
      TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.white);

  static final TextStyle headerText = GoogleFonts.lato(
      fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.primary);
}
