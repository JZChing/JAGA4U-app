import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/theme_provider.dart';

class AppColors {
  static const Color primary = Color(0xFF3498db);
  static const Color secondary = Color(0xFFa9dfbf);
  static const Color tertiary = Color(0xFFe74c3c);
  static const Color placeholder = Colors.grey;
  static const Color background = Color(0xFFf2f4f4);
}

class AppTextStyles {
  static TextStyle topAppBar(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return GoogleFonts.lato(
      fontSize: fontSize + 8.0,
      fontWeight: FontWeight.bold,
      color: Colors.black,
    );
  }

  static TextStyle bottomAppBar(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return GoogleFonts.lato(
      fontSize: fontSize + 8.0,
      fontWeight: FontWeight.bold,
      color: Colors.black,
    );
  }

  static TextStyle bodyText1(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return TextStyle(
      fontSize: fontSize,
      color: AppColors.secondary,
    );
  }

  static TextStyle placeholderText(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return TextStyle(
      fontSize: fontSize,
      color: AppColors.placeholder,
    );
  }

  static TextStyle buttonText(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return TextStyle(
      fontSize: fontSize - 1.0,
      fontWeight: FontWeight.bold,
      color: Colors.white,
    );
  }

  static TextStyle headerText(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    return GoogleFonts.lato(
      fontSize: fontSize + 4.0,
      fontWeight: FontWeight.bold,
      color: AppColors.primary,
    );
  }
}
