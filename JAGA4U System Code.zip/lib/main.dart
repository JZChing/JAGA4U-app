import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:mae_assignment/providers/CaregiverAlert_provider.dart';
import 'package:mae_assignment/providers/ProviderAlert_provider.dart';
import 'package:mae_assignment/providers/appointment_scheduler.dart';
import 'package:mae_assignment/providers/caregiverDashboardTable_provider.dart';
import 'package:mae_assignment/providers/elderlyMedicationSchedule_provider.dart';
import 'package:mae_assignment/providers/elderlyPatientSelection_provider.dart';
import 'package:mae_assignment/providers/health_log_providers.dart';
import 'package:mae_assignment/providers/location_service.dart';
import 'package:mae_assignment/providers/login_provider.dart';
import 'package:mae_assignment/providers/reminder_5mins_handler.dart';
import 'package:mae_assignment/providers/reviewHealthData_provider.dart';
import 'package:mae_assignment/providers/selectCaregiverProvider_provider.dart';
import 'package:mae_assignment/providers/selectElderlyPage_provider.dart';
import 'package:mae_assignment/providers/selectHealthcareProvider_provider.dart';
import 'package:mae_assignment/providers/viewElderlyHealthData_provider.dart';
import 'package:mae_assignment/repositories/appointment_repository.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'package:mae_assignment/screens/login.dart';
import 'providers/reminderNowNotification.dart'; // Import the new file

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  // Initialize the notification plugin
  const AndroidInitializationSettings androidInitializationSettings =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  final InitializationSettings initializationSettings =
      InitializationSettings(android: androidInitializationSettings);
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Create notification channel
  final AndroidNotificationChannel channel = AndroidNotificationChannel(
    'reminder_channel',
    'Reminder Notifications',
    description: 'This channel is for reminder notifications.',
    importance: Importance.high,
    playSound: true,
  );

  // Create notification channel in Android
  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(channel);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(
            create: (_) => ReminderHandler(flutterLocalNotificationsPlugin)),
        ChangeNotifierProvider(create: (_) => LocationService()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(
            create: (context) => SelectElderlyPageProvider()),
        ChangeNotifierProvider(create: (_) => HealthMetricsProvider()),
        ChangeNotifierProvider(create: (context) => MedicationProvider()),
        ChangeNotifierProvider(
            create: (context) => SelectHealthcareProviderPageProvider()),
        ChangeNotifierProvider(create: (context) => HealthDataProvider()),
        ChangeNotifierProvider(create: (_) => CaregiverAlertProvider()),
        ChangeNotifierProvider(create: (_) => ProviderAlertProvider()),
        ChangeNotifierProvider(
            create: (context) => SelectElderlyPatientPageProvider()),
        ChangeNotifierProvider(
            create: (_) =>
                ReminderNotificationHandler(flutterLocalNotificationsPlugin)),
        ChangeNotifierProvider(create: (context) => PatientDataProvider()),
        ChangeNotifierProvider(
            create: (context) => SelectCaregiverProviderPageProvider()),
        ChangeNotifierProvider(
            create: (context) => AssociatedMedicationProvider()),
        ChangeNotifierProvider(create: (_) => AppointmentRepository()),
        ChangeNotifierProvider(
            create: (context) => AppointmentSchedulerLogic(
                Provider.of<AppointmentRepository>(context, listen: false))),
      ],
      child: MyApp(flutterLocalNotificationsPlugin),
    ),
  );
}

class MyApp extends StatefulWidget {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  MyApp(this.flutterLocalNotificationsPlugin);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late ReminderHandler reminderHandler;
  late ReminderNotificationHandler
      reminderNotificationHandler; // New handler for notifications
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    reminderHandler = Provider.of<ReminderHandler>(context, listen: false);
    reminderNotificationHandler = Provider.of<ReminderNotificationHandler>(
        context,
        listen: false); // Initialize new handler

    // Set up the periodic reminder check every 5 seconds
    _timer = Timer.periodic(Duration(seconds: 5), (timer) {
      _runReminderCheck();
    });
  }

  // Function to handle reminder check for both the existing handler and the new one
  Future<void> _runReminderCheck() async {
    await reminderHandler.checkAndHandleReminders(); // Old reminder handling
    await reminderNotificationHandler
        .checkAndNotifyReminders(); // New reminder notifications handling
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return MaterialApp(
          title: 'My App',
          theme: themeProvider.themeData,
          home: LoginPage(),
        );
      },
    );
  }
}
