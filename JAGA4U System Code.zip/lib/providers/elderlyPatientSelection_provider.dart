import 'package:flutter/material.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/caregiver/viewElderlyLocation.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_provider_medicationSchedule.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_provider_viewHealthData.dart';

class SelectElderlyPatientPageProvider with ChangeNotifier {
  List<Map<String, String>> elderlyUsers = [];
  bool isLoading = true;
  final UserRepository _userRepository = UserRepository();

  Stream<List<Map<String, String>>> streamElderlyUsers(String providerID) {
    return _userRepository.streamAssociatedElderlyUsers(providerID);
  }

  Future<void> deleteElderlyUser(
      String providerID, String elderlyUserID, BuildContext context) async {
    try {
      await _userRepository.deleteAssociatedElderlyUser(
          providerID, elderlyUserID);

      await _userRepository.removeCaregiverFromElderlyUser(
          elderlyUserID, providerID);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Elderly user removed successfully.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to remove elderly user: $e")),
      );
    }
  }

  Future<void> addElderlyUser(
      String providerID, String username, BuildContext context) async {
    try {
      final elderlySnapshot = await _userRepository.getUserByUsername(username);
      final elderlyUserID = elderlySnapshot.id;
      final elderlyUsername = elderlySnapshot['username'];
      final role = elderlySnapshot['role'];

      // Check if the role is 'Elderly User'
      if (role == 'Elderly') {
        await _userRepository.addAssociatedElderlyUser(
            providerID, elderlyUserID, elderlyUsername);

        // Update the elderly user's document with the caregiver ID
        await _userRepository.updateElderlyUserWithCaregiverID(
            elderlyUserID, providerID);

        // Add to the local list and notify listeners
        elderlyUsers
            .add({'username': elderlyUsername, 'userID': elderlyUserID});
        notifyListeners(); // This updates the UI immediately
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User  is not an elderly user.")),
        );
      }
    } catch (e) {
      print("Error adding elderly user: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    }
  }

  void navigateToPage(
    BuildContext context,
    String elderlyID,
    String elderlyUsername,
    String destination,
    String providerID,
  ) {
    if (destination == 'healthData') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ViewHealthDataPage(
            elderlyID: elderlyID,
            elderlyUsername: elderlyUsername,
            providerId: providerID,
            caregiverID: '',
          ),
        ),
      );
    } else if (destination == 'medicationSchedule') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MedicationSchedulePage(
            elderlyUserID: elderlyID,
            elderlyUserName: elderlyUsername,
            providerID: providerID,
            caregiverID: '',
          ),
        ),
      );
    } else if (destination == 'viewElderlyLocation') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ViewElderlyLocationPage(
            elderlyID: elderlyID,
            elderlyUsername: elderlyUsername,
          ),
        ),
      );
    }
  }
}
