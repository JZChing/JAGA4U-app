import 'package:flutter/material.dart';
import 'package:mae_assignment/models/alert.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/repositories/alert_repository.dart';
import 'package:mae_assignment/repositories/medication_repository.dart';
import 'package:mae_assignment/repositories/reminder_repository.dart';

class ReminderAndAlertProvider with ChangeNotifier {
  final String elderlyUserID;
  final MedicationRepository _medicationRepo = MedicationRepository();
  final AlertRepository _alertRepo = AlertRepository();
  final ReminderRepository _reminderRepo = ReminderRepository();

  List<Map<String, dynamic>> _remindersWithMedications = [];
  List<Alert> _alerts = [];

  List<Map<String, dynamic>> get remindersWithMedications => _remindersWithMedications;
  List<Alert> get alerts => _alerts;

  ReminderAndAlertProvider(this.elderlyUserID);

  Future<void> fetchReminders() async {
    List<Map<String, dynamic>> reminders = (await _reminderRepo.getRemindersByElderlyUser(elderlyUserID))
      .map((reminder) => reminder.toJson()).toList();

    for (var reminder in reminders) {
      List<Medication> medications = await _medicationRepo.getMedicationsByElderlyUserAndMedicationID(elderlyUserID, reminder['medicationID']);
      reminder['medication'] = medications.isNotEmpty ? medications.first : null;
    }

    _remindersWithMedications = reminders;
    notifyListeners();
  }

  Future<void> fetchAlerts() async {
    _alerts = await _alertRepo.getAlertsForHealthcareProvider(elderlyUserID).first;
    notifyListeners();
  }
}
