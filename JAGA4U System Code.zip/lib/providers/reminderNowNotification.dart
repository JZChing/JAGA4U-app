import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:mae_assignment/models/reminder.dart';

class ReminderNotificationHandler with ChangeNotifier {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;

  ReminderNotificationHandler(this._flutterLocalNotificationsPlugin);

  // Function to check and notify about upcoming or expired reminders
  Future<void> checkAndNotifyReminders() async {
    try {
      final reminderRef = FirebaseFirestore.instance.collection('reminders');

      // Fetch reminders that are upcoming or expired but not yet notified
      final snapshot = await reminderRef
          .where('datetime', isLessThanOrEqualTo: Timestamp.now())
          .get();

      for (var doc in snapshot.docs) {
        Reminder reminder = Reminder.fromFirestore(doc);

        // Ensure the reminder is only processed if its status is "Pending"
        if (reminder.reminderStatus == 'Pending') {
          DateTime reminderTime = reminder.datetime.toDate();
          DateTime currentTime = DateTime.now();

          // Notify if the reminder time is now or within a 5-minute margin
          if (reminderTime.isBefore(currentTime.add(Duration(minutes: 1))) &&
              reminderTime
                  .isAfter(currentTime.subtract(Duration(minutes: 5)))) {
            // Send notification
            await _sendNotification(reminder);

            // After sending notification, update the Firestore document to mark it as 'Notified'
            await reminderRef
                .doc(doc.id)
                .update({'reminderStatus': 'Notified'});
          }
        }
      }
    } catch (e) {
      print('Error checking and notifying reminders: $e');
    }
  }

  Future<String> _getUserNameByID(String userID) async {
    try {
      final userSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userID)
          .get();

      if (userSnapshot.exists) {
        return userSnapshot['username']; // Assuming 'username' field exists
      } else {
        return 'Unknown User';
      }
    } catch (e) {
      print('Error fetching username: $e');
      return 'Unknown User';
    }
  }

  // Send local notifications
// Send local notifications
  Future<void> _sendNotification(Reminder reminder) async {
    try {
      // Fetch the elderly user's name using their ID
      String userName = await _getUserNameByID(reminder.elderlyUserID);

      // Update the notification title with the user's name
      final String title = "Reminder for $userName";
      final String body =
          "It's time to take your medication: ${reminder.medicationType}.";

      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
        'reminder_channel', // Channel ID
        'Reminder Notifications', // Channel Name
        channelDescription: 'This channel is for reminder notifications.',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
      );

      const NotificationDetails platformDetails = NotificationDetails(
        android: androidDetails,
      );

      await _flutterLocalNotificationsPlugin.show(
        0,
        title,
        body,
        platformDetails,
      );
    } catch (e) {
      print('Error sending notification: $e');
    }
  }
}
