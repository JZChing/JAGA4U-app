import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:mae_assignment/models/health_metrics.dart';
import 'package:mae_assignment/screens/caregiver/reviewHealthData.dart';

class HealthDataProvider with ChangeNotifier {
  
  Stream<List<HealthData>> healthDataStream(String elderlyID) {
    return FirebaseFirestore.instance
        .collection('HealthMetrics')
        .where('elderlyUserID', isEqualTo: elderlyID)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        final healthMetric = HealthMetrics.fromFirestore(doc);
        return HealthData(
          time: DateFormat('yyyy-MM-dd').format(healthMetric.dateTime.toDate()),
          bloodPressure: healthMetric.bloodPressure.toDouble(),
          pulseRate: healthMetric.pulseRate.toDouble(),
        );
      }).toList();
    });
  }
}

