import 'package:flutter/material.dart';
import 'package:mae_assignment/repositories/appointment_repository.dart';

class AppointmentSchedulerLogic extends ChangeNotifier {
  final AppointmentRepository _appointmentRepository;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  AppointmentSchedulerLogic(this._appointmentRepository);

  Future<void> saveAppointment(
      BuildContext context, String userID, String providerID) async {
    if (selectedDate != null && selectedTime != null) {
      final appointmentDateTime = DateTime(
        selectedDate!.year,
        selectedDate!.month,
        selectedDate!.day,
        selectedTime!.hour,
        selectedTime!.minute,
      );

      try {
        await _appointmentRepository.scheduleAppointment(
          userID,
          providerID,
          appointmentDateTime,
        );
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Appointment scheduled successfully!")),
        );
        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to schedule appointment: $e")),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select a date and time.")),
      );
    }
  }

  void setSelectedDate(DateTime? date) {
    selectedDate = date;
  }

  void setSelectedTime(TimeOfDay? time) {
    selectedTime = time;
  }
}
