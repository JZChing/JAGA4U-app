import 'package:flutter/foundation.dart';
import 'package:mae_assignment/models/health_metrics.dart';
import 'package:mae_assignment/repositories/healthMetrics_repository.dart';
import 'package:mae_assignment/providers/alert_service_providers.dart';
import 'package:mae_assignment/screens/FCMService.dart';
import 'emergency_providers.dart';
import 'package:mae_assignment/screens/authservice.dart';  // Assuming you've imported AuthService

class HealthMetricsProvider with ChangeNotifier {
  final EmergencyService emergencyService = EmergencyService();
  final AlertService alertService = AlertService();
  final HealthMetricsRepository healthMetricsRepository = HealthMetricsRepository();
  final FCMService fcmService = FCMService();  // Instantiate FCMService
  final AuthService authService = AuthService();  // Instantiate AuthService

  List<HealthMetrics> _healthMetrics = [];
  List<HealthMetrics> get healthMetrics => _healthMetrics;

  Future<void> fetchHealthData(String userID) async {
    try {
      _healthMetrics = await healthMetricsRepository.fetchHealthData(userID);
      notifyListeners(); // Notify listeners after updating data
    } catch (e) {
      print("Error fetching health data in provider: $e");
    }
  }

  Future<void> logHealthData(String userID, String bloodPressure, String pulseRate) async {
    double bpValue = double.parse(bloodPressure);
    double prValue = double.parse(pulseRate);
    bool isEmergency = checkEmergencyStatus(bpValue, prValue);

    try {
      // Log health data in repository
      await healthMetricsRepository.logHealthData(userID, bloodPressure, pulseRate, isEmergency);

      // Check if an emergency condition was detected
      if (isEmergency) {
        print("Emergency detected! Proceeding with alert and push notification.");

        // Get caregiver and healthcare provider IDs
        final ids = await alertService.getCaregiverAndHealthcareProviderIDs(userID);
        List<String> medicationIDs = await alertService.getMedicationIDs(userID);

        // Create an alert if emergency status is true
        await alertService.createAlert(
          elderlyUserID: userID,
          caregiverIDs: ids['caregiverID'] ?? [],
          healthcareProviderIDs: ids['healthcareProviderIDs'] ?? [],
          medicationID: medicationIDs,
        );

        // Loop through each caregiver ID and send push notification
        List<String> caregiverIds = List<String>.from(ids['caregiverID'] ?? []);  // Ensure the caregiver IDs are in a list

        for (String caregiverId in caregiverIds) {
          // Fetch the caregiver's FCM token
          String? caregiverFcmToken = await fcmService.getRecipientFcmToken(caregiverId);

          if (caregiverFcmToken != null) {
            print("Caregiver's FCM token: $caregiverFcmToken");

            // Send a push notification to the caregiver
            await fcmService.sendPushNotification(
              caregiverFcmToken,
              "Emergency alert! Please check the elderly person's health metrics.",
              "Health data alert"
            );
          } else {
            print("Caregiver's FCM token is null. Cannot send push notification.");
          }
        }
      }
    } catch (e) {
      print("Error logging health data: $e");
    }
  }

  Future<void> initiateEmergency(String userID) async {
    try {
      await emergencyService.initiateEmergency(userID);
    } catch (e) {
      print("Error initiating emergency: $e");
    }
  }

  bool checkEmergencyStatus(double bloodPressure, double pulseRate) {
    // Emergency if blood pressure is out of range or pulse rate is abnormal
    return (bloodPressure > 130 || bloodPressure < 90 || pulseRate < 60 || pulseRate > 100);
  }
}
