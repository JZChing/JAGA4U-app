import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/authService.dart';
import 'package:mae_assignment/screens/caregiver/caregiverDashboard.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_dashboard.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_providers_dashboard.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final UserRepository _userRepository = UserRepository(); // Initialize UserRepository

  Future<void> signIn(BuildContext context, String username, String password) async {
    try {
      // Find user by username in Firestore
      DocumentSnapshot? userDoc = await _userRepository.getUserByUsername(username);

      String userEmail = userDoc['email'];
      String userID = userDoc.id;

      // Authenticate with Firebase using the retrieved email and entered password
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: userEmail,
        password: password,
      );

      if (userCredential.user != null) {
        // After successful login or registration
        final authService = AuthService();
        await authService.saveUserToken(userID);
        authService.setupTokenRefresh(userID);

        // Get user role
        String userRole = _userRepository.getUserRole(userDoc);

        // Navigate to the correct dashboard based on role
        if (userRole == 'Caregiver') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => CaregiverDashboardPage(userID: userID),
            ),
          );
        } else if (userRole == 'Elderly') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ElderlyDashboardPage(userID: userID),
            ),
          );
        } else if (userRole == 'Healthcare Provider') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => HealthcareProviderDashboardPage(userID: userID),
            ),
          );
        }
      } else {
        _showError(context, "Authentication failed. Please try again.");
      }
        } catch (e) {
      _showError(context, "Failed to sign in. Please check your credentials.");
      print(e); // For debugging
    }
  }

  void _showError(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }
}

