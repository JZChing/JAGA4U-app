import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class LocationProvider {
  // Request location permission before starting location services
  Future<void> checkLocationPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Check if location services are enabled
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw 'Location services are disabled.';
    }

    // Check location permission
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw 'Location permission denied';
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw 'Location permissions are permanently denied. Please enable in settings.';
    }
  }

  // Get live location stream and save location to Firestore
  Stream<LatLng> getLiveLocationStream({required String userID}) {
    LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    );

    return Geolocator.getPositionStream(locationSettings: locationSettings).map((Position position) {
      print("Received position: ${position.latitude}, ${position.longitude}"); // Debugging line
      _saveLocationToFirestore(userID, position.latitude, position.longitude);
      return LatLng(position.latitude, position.longitude);
    });
  }

  // Save the location to Firestore
  Future<void> _saveLocationToFirestore(String userID, double latitude, double longitude) async {
    try {
      await FirebaseFirestore.instance.collection('locations').doc(userID).set(
        {
          'latitude': latitude,
          'longitude': longitude,
          'timestamp': DateTime.now(),
          'elderlyID': userID,
        },
        SetOptions(merge: true),
      );
      print("Location saved to Firestore");
    } catch (e) {
      print("Error saving location: $e");
    }
  }

    // Get the current location of the user
  Future<LatLng> getCurrentLocation() async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    return LatLng(position.latitude, position.longitude);
  }

  // Public method to update location in Firestore
  Future<void> updateLocationInDatabase({required String userID, required LatLng position}) async {
    await _saveLocationToFirestore(userID, position.latitude, position.longitude);
  }
}
