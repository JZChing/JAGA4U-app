import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/alert.dart';

class AlertService {
  static Future<List<Alert>> fetchAlerts(String userID) async {
    try {
      final alertSnapshot = await FirebaseFirestore.instance
          .collection('alerts')
          .where('elderlyID', isEqualTo: userID)
          .get();

      return alertSnapshot.docs
          .map((doc) => Alert.fromFirestore(doc))
          .toList();
    } catch (e) {
      print("Error fetching alerts: $e");
      return [];
    }
  }
}
