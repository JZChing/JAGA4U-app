// caregiver_alert_provider.dart
import 'package:flutter/material.dart';
import 'package:mae_assignment/models/alert.dart';
import 'package:mae_assignment/repositories/alert_repository.dart';

class CaregiverAlertProvider extends ChangeNotifier {
  List<Alert> _alerts = [];
  List<Alert> get alerts => _alerts;
  final AlertRepository _alertRepository = AlertRepository();

  Future<void> fetchAlertsCaregiver(String caregiverID) async {
    try {
      _alerts = await _alertRepository.fetchAlertsForCaregiver(caregiverID);
      notifyListeners();
    } catch (e) {
      print('Error retrieving alerts for caregiver: $e');
    }
  }

  Future<void> deleteAlert(int index) async {
    try {
      String alertID = _alerts[index].alertID;

      await _alertRepository.deleteAlert(alertID);

      _alerts.removeAt(index);
      notifyListeners();
    } catch (e) {
      print('Error deleting alert: $e');
    }
  }
}

