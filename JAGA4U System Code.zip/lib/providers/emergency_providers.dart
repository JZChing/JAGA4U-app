import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';

class EmergencyService {
  Future<void> initiateEmergency(String elderlyUserID) async {
    try {
      await handleEmergency(elderlyUserID);
    } catch (e) {
      print("Emergency handling failed: $e");
      throw Exception("Failed to initiate emergency.");
    }
  }

  Future<void> handleEmergency(String elderlyUserID) async {
    try {
      DocumentSnapshot elderlyUserDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(elderlyUserID)
          .get();

      if (!elderlyUserDoc.exists) {
        print("No elderly user found with ID: $elderlyUserID");
        return;
      }

      // Get the list of caregiver IDs (now it's an array)
      List<dynamic> caregiverIDs = elderlyUserDoc['caregiverID'] ?? [];

      if (caregiverIDs.isEmpty) {
        print("No caregivers associated with elderly user ID: $elderlyUserID");
        return;
      }

      for (var caregiverID in caregiverIDs) {
        // Fetch each caregiver's document
        DocumentSnapshot caregiverDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(caregiverID)
            .get();

        if (caregiverDoc.exists) {
          String? contactInfo = caregiverDoc['contactInfo'];
          if (contactInfo != null && contactInfo.isNotEmpty) {
            await callCaregiver(contactInfo);
          } else {
            print("No valid contact info found for caregiver with ID: $caregiverID.");
          }
        } else {
          print("Caregiver with ID: $caregiverID does not exist.");
        }
      }
    } catch (e) {
      print("Error handling emergency: $e");
      throw Exception("Failed to handle emergency.");
    }
  }

Future<void> callCaregiver(String caregiverContact) async {
  // Ensure that the phone number is valid and properly formatted
  caregiverContact = caregiverContact.replaceAll(RegExp(r'\D'), ''); // Remove non-numeric characters

  final String telUri = 'tel:$caregiverContact';

  try {
    // Check if the device can launch the phone call
    bool canLaunchCall = await canLaunch(telUri);

    if (canLaunchCall) {
      // Launch the phone call
      await launch(telUri);
      print("Call launched successfully.");
    } else {
      print("Cannot launch call to $caregiverContact. Invalid phone number format or device issue.");
    }
  } catch (e) {
    print("Error launching call: $e");
  }
}

}
