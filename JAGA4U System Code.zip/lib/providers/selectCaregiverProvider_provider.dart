import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/chatScreen.dart';

class SelectCaregiverProviderPageProvider with ChangeNotifier {
  List<Map<String, String>> HealthcareProvider = [];
  bool isLoading = true;
  final UserRepository userRepository = UserRepository();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  Stream<List<Map<String, String>>> streamCaregivers(String providerID) {
    return userRepository.streamCaregivers(providerID);
  }

  Future<void> deleteCaregiver(
      String caregiverID, String providerID, BuildContext context) async {
    try {
      await userRepository.deleteAssociatedHealthcareProviders(
          caregiverID, providerID);

      await userRepository.removeCaregiverFromHealthcareProvider(
          providerID, caregiverID);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Healthcare provider removed successfully.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to remove healthcare provider: $e")),
      );
    }
  }

  Future<void> addCaregiver(
      String providerID, String username, BuildContext context) async {
    try {
      final caregiverSnapshot =
          await userRepository.getUserByUsername(username); //
      final caregiverID = caregiverSnapshot.id;
      final caregiverUsername = caregiverSnapshot['username'];
      final role = caregiverSnapshot['role'];

      // Check if the role is 'Healthcare Provider'
      if (role == 'Caregiver') {
        // Add the healthcare provider to the caregiver's associated providers

        await userRepository.addAssociatedHealthcareProvider(
            caregiverID, providerID, caregiverUsername);

        // Update the Healthcare Provider document with the caregiver ID
        await userRepository.updateHealthcareProviderWithCaregiverID(
            providerID, caregiverID);

        // Add to the local list and notify listeners
        HealthcareProvider.add(
            {'username': caregiverUsername, 'userID': providerID});
        notifyListeners(); // This updates the UI immediately
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User  is not a Caregiver")),
        );
      }
    } catch (e) {
      print("Error adding Caregiver: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    }
  }

  Future<String> getOrCreateChatID(
      String caregiverID, String healthcareProviderID) async {
    // Define the chat collection
    final chatCollection = firestore.collection('chats');

    // Sort IDs to ensure a consistent order
    List<String> ids = [caregiverID, healthcareProviderID];
    ids.sort();
    String chatDocID = ids.join("_");

    // Check if chat document already exists
    DocumentSnapshot chatDocSnapshot =
        await chatCollection.doc(chatDocID).get();

    if (!chatDocSnapshot.exists) {
      // If not, create a new document with this ID
      await chatCollection.doc(chatDocID).set({
        'participants': [caregiverID, healthcareProviderID],
        'createdAt': FieldValue.serverTimestamp(),
      });
    }

    return chatDocID;
  }

  Future<void> navigateToPage(
    BuildContext context,
    String providerID,
    String HealthcareProviderUsername,
    String caregiverID,
  ) async {
    // Retrieve or create the chat ID from Firebase
    String chatID = await getOrCreateChatID(caregiverID, providerID);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
            chatID: chatID,
            recipientName: HealthcareProviderUsername,
            senderID: caregiverID,
            recipientID: providerID),
      ),
    );
  }
}
