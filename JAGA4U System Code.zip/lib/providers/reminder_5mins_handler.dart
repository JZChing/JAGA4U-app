import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:mae_assignment/models/reminder.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class ReminderHandler with ChangeNotifier {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;

  ReminderHandler(this._flutterLocalNotificationsPlugin);

  // This function will check and handle expired reminders
  Future<void> checkAndHandleReminders() async {
    try {
      final reminderRef = FirebaseFirestore.instance.collection('reminders');

      // Fetch reminders that are already expired
      final snapshot = await reminderRef
          .where('datetime', isLessThan: Timestamp.now())
          .get();

      for (var doc in snapshot.docs) {
        Reminder reminder = Reminder.fromFirestore(doc);

        // Only proceed if the reminder is 'pending'
        if (reminder.isExpired() && reminder.reminderStatus != 'completed') {
          // Delete the expired reminder from Firestore
          await reminderRef.doc(doc.id).delete();

          // Delete associated medication based on medicationID
          await _deleteMedication(reminder.medicationID);

          // Validate elderly user before proceeding
          await _validateElderlyUserAndSendNotifications(reminder);

          // After deletion, create and store the alert
          await _createAlert(reminder);
        } else {
          print('Skipping reminder as it is either completed or not expired.');
        }
      }
    } catch (e) {
      print('Error checking and handling reminders: $e');
    }
  }

  // Fetch caregiver IDs based on elderlyUserID
  Future<List<String>> _getCaregiverIDs(String elderlyUserID) async {
    try {
      final elderlyUserSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(elderlyUserID)
          .get();

      // Extract the caregiverIDs array from the elderly user document
      List<String> caregiverIDs = List<String>.from(
        elderlyUserSnapshot['caregiverID'] ?? [], // Safely extract array
      );

      return caregiverIDs;
    } catch (e) {
      print('Error fetching caregiver IDs: $e');
      return [];
    }
  }

  // Fetch healthcare provider IDs based on elderlyUserID
  Future<List<String>> _getHealthcareProviderIDs(String elderlyUserID) async {
    try {
      final elderlyUserSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(elderlyUserID)
          .get();

      // Extract the healthcareProviderIDs array from the elderly user document
      List<String> healthcareProviderIDs = List<String>.from(
        elderlyUserSnapshot['healthcareProviderID'] ?? [], // Safely extract array
      );

      return healthcareProviderIDs;
    } catch (e) {
      print('Error fetching healthcare provider IDs: $e');
      return [];
    }
  }


  Future<void> _createAlert(Reminder reminder) async {
    try {
      final alertRef = FirebaseFirestore.instance.collection('alerts');
      List<String> caregiverIDs =
          await _getCaregiverIDs(reminder.elderlyUserID);
      List<String> healthcareProviderIDs =
          await _getHealthcareProviderIDs(reminder.elderlyUserID);

      print('Fetched Caregiver IDs: $caregiverIDs');
      print('Fetched Healthcare Provider IDs: $healthcareProviderIDs');

      // Generate a unique alertID using the Firestore document ID or any other method
      final alertID = alertRef.doc().id; // This will auto-generate a unique ID

      // Prepare the alert data
      Map<String, dynamic> alertData = {
        'alertID': alertID, // Use the generated alertID here
        'alertStatus': 'Reminder Expired, missed medication',
        'alertTime': Timestamp.now(),
        'caregiverIDs': caregiverIDs, // Get caregiver IDs
        'elderlyID': reminder.elderlyUserID, // Elderly user ID from the reminder
        'healthcareProviderIDs': healthcareProviderIDs, // Get healthcare provider IDs
        'medicationID': reminder.medicationID, // Medication IDs from the reminder
      };

      // Store the alert in Firestore
      await alertRef
          .doc(alertID)
          .set(alertData); // Add the alert using the generated alertID
      print('Alert created for reminder expired.');
    } catch (e) {
      print('Error creating alert: $e');
    }
  }

  // Delete medication by medicationID
  Future<void> _deleteMedication(String medicationID) async {
    try {
      final medicationRef =
          FirebaseFirestore.instance.collection('medications');
      final medicationSnapshot = await medicationRef
          .where('medicationID', isEqualTo: medicationID)
          .get();

      for (var doc in medicationSnapshot.docs) {
        await medicationRef.doc(doc.id).delete();
        print('Medication ${doc.id} deleted.');
      }
    } catch (e) {
      print('Error deleting medication: $e');
    }
  }

  Future<void> _validateElderlyUserAndSendNotifications(
      Reminder reminder) async {
    try {
      // Validate that the elderly user exists in the 'users' collection
      final elderlyUserSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('userID', isEqualTo: reminder.elderlyUserID)
          .where('role', isEqualTo: 'Elderly')
          .get();

      // If the elderly user is found, proceed to send notifications
      if (elderlyUserSnapshot.docs.isNotEmpty) {
        print('Elderly user validated: ${reminder.elderlyUserID}');

        // Fetch caregiver and healthcare provider IDs associated with the elderly user
        List<String> caregiverIDs =
            await _getCaregiverIDs(reminder.elderlyUserID);
        List<String> healthcareProviderIDs =
            await _getHealthcareProviderIDs(reminder.elderlyUserID);

        // Print out the IDs for debugging
        print('Caregivers: $caregiverIDs');
        print('Healthcare Providers: $healthcareProviderIDs');

        // Combine elderly user ID with caregiver and healthcare provider IDs
        List<String> allUserIDs = [
          reminder.elderlyUserID, // Add elderly user ID
          ...caregiverIDs, // Add caregiver IDs
          ...healthcareProviderIDs, // Add healthcare provider IDs
        ];

        // Send notifications to all users in the list
        await _sendLocalNotifications(allUserIDs, reminder);
      } else {
        print('Elderly user not found, no notifications sent.');
      }
    } catch (e) {
      print('Error validating elderly user or sending notifications: $e');
    }
  }

// Fetch elderly user's name by elderlyUserID
Future<String> _getElderlyUserName(String elderlyUserID) async {
  try {
    final userSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(elderlyUserID)
        .get();

    if (userSnapshot.exists) {
      return userSnapshot['username']; // Assuming 'username' holds the elderly user's name
    } else {
      return 'Unknown Elderly User';
    }
  } catch (e) {
    print('Error fetching elderly user name: $e');
    return 'Unknown Elderly User';
  }
}

// Send notifications with elderly user name in the header
Future<void> _sendLocalNotifications(List<String> userIDs, Reminder reminder) async {
  try {
    // Fetch the elderly user's name
    String elderlyName = await _getElderlyUserName(reminder.elderlyUserID);

    for (var userID in userIDs) {
      // Prepare the notification content
      String title = "Reminder Expired for $elderlyName";
      String body = "Reminder for medication ${reminder.medicationType} has expired.";

      // Show the notification for each user
      await _showLocalNotification(title, body);
    }
  } catch (e) {
    print('Error sending local notifications: $e');
  }
}


  Future<String> _getUserNameByID(String userID) async {
    try {
      final userSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(userID)
          .get();

      if (userSnapshot.exists) {
        return userSnapshot['username']; // Assuming 'username' field exists
      } else {
        return 'Unknown User';
      }
    } catch (e) {
      print('Error fetching username: $e');
      return 'Unknown User';
    }
  }

  Future<void> _showLocalNotification(String title, String body) async {
    try {
      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
        'reminder_channel', // Channel ID
        'Reminder Notifications', // Channel Name
        channelDescription: 'This channel is for reminder notifications.',
        importance: Importance.high,
        priority: Priority.high,
      );

      const NotificationDetails platformDetails = NotificationDetails(
        android: androidDetails,
      );

      await _flutterLocalNotificationsPlugin.show(
        0, // Notification ID
        title,
        body,
        platformDetails,
      );
    } catch (e) {
      print('Error showing local notification: $e');
    }
  }
}
