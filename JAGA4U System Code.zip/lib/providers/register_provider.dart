import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mae_assignment/models/user.dart';
import 'package:mae_assignment/repositories/user_repository.dart';

class RegisterProvider {
  final UserRepository userService = UserRepository();

  Future<void> registerUser (BuildContext context, {
    required String username,
    required String password,
    required String email,
    required String contactInfo,
    required String? selectedRole,
  }) async {
    if (_validateInputs(username, password, email, selectedRole, contactInfo)) {
      try {
        // Check if the username is unique
        final isUnique = await userService.isUsernameUnique(username);
        if (!isUnique) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Username is already taken. Please choose another one.')),
          );
          return;
        }

        // Prepare new user data
        final newUser  = UserData(
          userID: '', // Firebase Auth generated user ID will be set later
          username: username,
          password: password, // Hash in production
          email: email,
          role: selectedRole ?? '', // Role from dropdown
          contactInfo: contactInfo,
          createdAt: Timestamp.now(),
        );

        // Register the user
        await userService.registerUser (newUser);

        // Show success message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('User  registered successfully!')),
        );

        // Navigate to login page
        Navigator.pop(context);

      } catch (e) {
        // Handle error with a message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    } else {
      // Show message if validation fails
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill out all fields')),
      );
    }
  }

  bool _validateInputs(String username, String password, String email, String? selectedRole, String contactInfo) {
    return username.isNotEmpty &&
        password.isNotEmpty &&
        email.isNotEmpty &&
        selectedRole != null &&
        contactInfo.isNotEmpty;
  }
}