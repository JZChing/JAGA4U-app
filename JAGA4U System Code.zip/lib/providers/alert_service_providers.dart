import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/alert.dart';

class AlertService {
  Future<void> createAlert({
    required String elderlyUserID,
    required List<String> caregiverIDs,
    required List<String> healthcareProviderIDs,
    required List<String> medicationID,
  }) async {
    print('Creating alert with:');
    print('Elderly User ID: $elderlyUserID');
    print('Caregiver IDs: $caregiverIDs');
    print('Healthcare Provider IDs: $healthcareProviderIDs');
    print('Medication IDs: $medicationID');
    String alertID = FirebaseFirestore.instance.collection('alerts').doc().id;
    Timestamp alertTime = Timestamp.now();

    Alert alert = Alert(
      alertID: alertID,
      alertTime: alertTime,
      alertStatus: 'BP Value or PR Value Abnormal',
      caregiverIDs: caregiverIDs,
      healthcareProviderIDs: healthcareProviderIDs,
      medicationID: medicationID,
      elderlyID: elderlyUserID,
    );

    try {
      await FirebaseFirestore.instance
          .collection('alerts')
          .doc(alertID)
          .set(alert.toJson());
      print('Alert created successfully');
    } catch (e) {
      print('Error creating alert: $e');
    }
  }

  Future<Map<String, dynamic>> getCaregiverAndHealthcareProviderIDs(
      String elderlyUserID) async {
    List<String> caregiverID = [];
    List<String> healthcareProviderIDs = [];

    try {
      QuerySnapshot userSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('userID', isEqualTo: elderlyUserID)
          .get();

      print('User snapshot retrieved: ${userSnapshot.docs}');
      if (userSnapshot.docs.isNotEmpty) {
        var userData = userSnapshot.docs.first.data() as Map<String, dynamic>;
        print('User data: $userData'); // Log full user data
        caregiverID = List<String>.from(userData['caregiverID'] ?? []);
        healthcareProviderIDs =
            List<String>.from(userData['healthcareProviderID'] ?? []);
        print('Caregiver IDs: $caregiverID');
        print('Healthcare Provider IDs: $healthcareProviderIDs');
      } else {
        print('No user document found for elderlyUserID: $elderlyUserID');
      }
    } catch (e) {
      print('Error retrieving caregiver and healthcare provider IDs: $e');
    }

    return {
      'caregiverID': caregiverID,
      'healthcareProviderIDs': healthcareProviderIDs,
    };
  }

  Future<List<String>> getMedicationIDs(String elderlyUserID) async {
    List<String> medicationIDs = [];

    try {
      // Query the medication IDs associated with the elderly user
      QuerySnapshot medicationProviderSnapshot = await FirebaseFirestore
          .instance
          .collection('medications')
          .where('elderlyUserID', isEqualTo: elderlyUserID)
          .get();

      // Retrieve all medication IDs for the user
      for (var doc in medicationProviderSnapshot.docs) {
        var medIDs = doc['medicationID'];

        // Check if medIDs is a List
        if (medIDs is List) {
          medicationIDs.addAll(List<String>.from(medIDs));
        } else if (medIDs is String) {
          // If it's a single string, add it directly
          medicationIDs.add(medIDs);
        }
      }
    } catch (e) {
      print('Error retrieving medicationIDs: $e');
    }

    return medicationIDs;
  }

  Future<List<Alert>> getAlertsForCaregiver(String caregiverID) async {
    List<Alert> alerts = [];

    try {
      QuerySnapshot alertSnapshot = await FirebaseFirestore.instance
          .collection('alerts')
          .where('caregiverIDs', arrayContains: caregiverID)
          .get();

      // Map each document to an Alert instance using Alert.fromFirestore
      alerts = alertSnapshot.docs.map((doc) => Alert.fromFirestore(doc)).toList();
    } catch (e) {
      print('Error retrieving alerts for caregiver: $e');
    }

    return alerts;
  }

}
