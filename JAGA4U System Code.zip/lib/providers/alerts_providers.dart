import 'package:flutter/material.dart';
import 'package:mae_assignment/models/alert.dart';
import 'package:mae_assignment/repositories/alert_repository.dart';

class AlertProvider extends ChangeNotifier {
  final AlertRepository _alertRepository = AlertRepository();
  List<Alert> _alerts = [];

  List<Alert> get alerts => _alerts;

  // Fetch alerts for a specific elderly user using AlertRepository
  Stream<List<Alert>> fetchAlerts(String elderlyID) {
    return _alertRepository.fetchAlertsForElderly(elderlyID).map((alertList) {
      _alerts = alertList;
      notifyListeners();
      return _alerts;
    });
  }

  // Update alert status using AlertRepository
  Future<void> updateAlertStatus(String alertID, String status) async {
    await _alertRepository.updateAlertStatus(alertID, status);
    notifyListeners();
  }

  // Delete an alert using AlertRepository
  Future<void> deleteAlert(String alertID) async {
    await _alertRepository.deleteAlert(alertID);
    notifyListeners();
  }
}
