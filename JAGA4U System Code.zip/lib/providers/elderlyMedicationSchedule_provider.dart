import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/models/reminder.dart';
import 'package:mae_assignment/repositories/medication_repository.dart';
import 'package:mae_assignment/repositories/reminder_repository.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';

class MedicationProvider extends ChangeNotifier {
  int selectedIndex = 2;
  final medicationRepository = MedicationRepository();
  final reminderRepository = ReminderRepository();
  // Handle navigation based on the selected index
  void onItemTapped(BuildContext context, int index, String caregiverID) {
    selectedIndex = index;
    // Call the global navigation handler here
    handleBottomNavigationTap(context, index, caregiverID);
    notifyListeners();
  }

  // Stream to get medications
  Stream<List<Medication>> medicationsStream(String elderlyUserID) {
    return medicationRepository.fetchMedicationsStream(elderlyUserID);
  }

  // Add a new medication entry to Firestore
  Future<void> addMedication(BuildContext context, String elderlyUserID) async {
    String medicationType = '';
    String dosage = '';
    DateTime? selectedDate;
    TimeOfDay? selectedTime;
    String medicationStatus = 'Scheduled';

    await showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text("Add Medication"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    decoration: InputDecoration(labelText: 'Medication Type'),
                    onChanged: (value) {
                      medicationType = value;
                    },
                  ),
                  TextField(
                    decoration: InputDecoration(labelText: 'Dosage'),
                    onChanged: (value) {
                      dosage = value;
                    },
                  ),
                  ListTile(
                    title: Text(
                      selectedDate == null
                          ? 'Select Date'
                          : 'Date: ${selectedDate!.toLocal().toString().split(' ')[0]}',
                    ),
                    trailing: Icon(Icons.calendar_today),
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2101),
                      );
                      if (pickedDate != null) {
                        setState(() {
                          selectedDate = pickedDate;
                        });
                      }
                    },
                  ),
                  ListTile(
                    title: Text(
                      selectedTime == null
                          ? 'Select Time'
                          : 'Time: ${selectedTime!.format(context)}',
                    ),
                    trailing: Icon(Icons.access_time),
                    onTap: () async {
                      TimeOfDay? pickedTime = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.now(),
                      );
                      if (pickedTime != null) {
                        setState(() {
                          selectedTime = pickedTime;
                        });
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text("Cancel"),
                ),
                TextButton(
                  onPressed: () async {
                    if (medicationType.isNotEmpty &&
                        dosage.isNotEmpty &&
                        selectedDate != null &&
                        selectedTime != null) {
                      try {
                        // Combine the selected date and time into a single DateTime object
                        final dateTime = DateTime(
                          selectedDate!.year,
                          selectedDate!.month,
                          selectedDate!.day,
                          selectedTime!.hour,
                          selectedTime!.minute,
                        );

                        // Create a new Medication object
                        final newMedication = Medication(
                          medicationID: '',
                          medicationType: medicationType,
                          dosage: dosage,
                          dateTime: dateTime,
                          medicationStatus: medicationStatus,
                          elderlyUserID: elderlyUserID,
                        );

                        // Add Medication to Firestore
                        final docRef = await medicationRepository.addMedication(newMedication);
                        await medicationRepository.updateMedicationID(docRef.id);

                        // Create a new Reminder associated with the Medication
                        final newReminder = Reminder(
                          reminderID: '',
                          elderlyUserID: elderlyUserID,
                          medicationID: docRef.id, // Link to medication document ID
                          medicationType: medicationType,
                          reminderStatus: 'Pending',
                          datetime: Timestamp.fromDate(dateTime),
                          delayAlert: '0', // Set delayAlert as needed
                        );

                        // Add Reminder to Firestore
                        final reminderDocRef = await reminderRepository.addReminder(newReminder);
                        await reminderRepository.updateReminderID(reminderDocRef.id);
                        Navigator.of(context).pop();
                      } catch (e) {
                        print("Error adding medication or reminder: $e");
                      }
                    }
                  },
                  child: Text("Save"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> deleteMedication(String elderlyUserID, String medicationID) async {
    try {
      // Delete the medication entry from Firestore
      await medicationRepository.deleteMedication(medicationID);

      // Delete the associated reminder entry from Firestore
      await reminderRepository.deleteReminderByMedicationID(medicationID);

      notifyListeners(); // Notify listeners to update the UI
    } catch (e) {
      print("Error deleting medication or reminder: $e");
    }
  }

}
