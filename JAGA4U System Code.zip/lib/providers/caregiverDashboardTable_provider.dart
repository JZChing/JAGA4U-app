import 'package:flutter/material.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/repositories/medication_repository.dart';
import 'package:mae_assignment/repositories/user_repository.dart';

class AssociatedMedicationProvider with ChangeNotifier {
  final MedicationRepository medicationRepository = MedicationRepository();
  final UserRepository userRepository = UserRepository();

  List<Medication> _medications = [];
  List<Medication> get medications => _medications;

  List<Map<String, dynamic>> _medicationsWithNames = [];
  List<Map<String, dynamic>> get medicationsWithNames => _medicationsWithNames;

  // Fetch today's medication schedule for elderly users associated with a caregiver
  Future<void> fetchTodaysMedicationSchedule(String caregiverID) async {
    try {
      // Step 1: Retrieve associated elderly user IDs
      List<String> elderlyUserIDs = await userRepository.fetchAssociatedElderlyUserIDs(caregiverID);

      List<Medication> allMedications = [];

      // Step 2: Use the existing repository function for each userID
      for (String elderlyUserID in elderlyUserIDs) {
        List<Medication> medicationsForUser = await medicationRepository.fetchMedicationsForUserToday(elderlyUserID);
        allMedications.addAll(medicationsForUser);
      }

      // Update the local state and notify listeners
      _medications = allMedications;
      notifyListeners();
    } catch (e) {
      print("Error fetching today's medication schedule: $e");
    }
  }

  Future<void> fetchMedicationsWithUserNames(String caregiverID) async {
    try {
      // Step 1: Fetch today's medication schedules
      await fetchTodaysMedicationSchedule(caregiverID);

      // Step 2: Retrieve user names for each medication
      List<Map<String, dynamic>> medicationsWithUserNames = [];

      for (var medication in _medications) {
        final String elderlyUserID = medication.elderlyUserID;

        // Fetch elderly user's name using UserRepository
        String? elderlyUserName = await userRepository.getElderlyUserNameByID(elderlyUserID);

        medicationsWithUserNames.add({
          'medication': medication,
          'userName': elderlyUserName ?? 'User name not found',
        });
      }

      _medicationsWithNames = medicationsWithUserNames;
      notifyListeners();
    } catch (e) {
      print("Error fetching medications with user names: $e");
    }
  }
}