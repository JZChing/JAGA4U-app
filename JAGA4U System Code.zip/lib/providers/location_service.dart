import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mae_assignment/providers/location_providers.dart';
import 'dart:async';

class LocationService with ChangeNotifier {
  final LocationProvider _locationProvider = LocationProvider();
  StreamSubscription? locationSubscription;
  Timer? locationUpdateTimer;
  LatLng currentLocation = LatLng(0, 0);
  bool isSharingLocation = false;
  
  // Start location updates
  void startLocationSharing(String userID) async {
    if (isSharingLocation) return;

    isSharingLocation = true;
    notifyListeners();

    await _locationProvider.checkLocationPermission();

    locationSubscription = _locationProvider
        .getLiveLocationStream(userID: userID)
        .listen((position) {
      currentLocation = position;
      // Notify listeners to update the UI
      notifyListeners();
    });

    locationUpdateTimer = Timer.periodic(Duration(seconds: 10), (_) {
      if (isSharingLocation) _updateLocation(userID);
    });
  }

  // Stop location updates
  void stopLocationSharing() {
    locationSubscription?.cancel();
    locationUpdateTimer?.cancel();
    isSharingLocation = false;
    notifyListeners();
  }

  // Update location manually
  void _updateLocation(String userID) async {
    try {
      final position = await _locationProvider.getCurrentLocation();
      currentLocation = position;
      // Update the database with the new location
      _locationProvider.updateLocationInDatabase(userID: userID, position: position);
      notifyListeners();
    } catch (e) {
      print("Failed to update location: $e");
    }
  }

  // Getter for current location
  LatLng getCurrentLocation() => currentLocation;

  // Getter for location sharing status
  bool getIsSharingLocation() => isSharingLocation;
}
