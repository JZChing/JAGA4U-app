// ProviderSelection.dart
import 'package:flutter/material.dart';
import 'package:mae_assignment/repositories/user_repository.dart';

class ProviderSelection extends StatelessWidget {
  final Function(String providerID) onProviderSelected;
  final UserRepository _providerRepository = UserRepository();

  ProviderSelection({required this.onProviderSelected});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _providerRepository.fetchHealthcareProviders(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text("No healthcare providers available."));
        } else {
          final providers = snapshot.data!;
          return ListView.builder(
            itemCount: providers.length,
            itemBuilder: (context, index) {
              final provider = providers[index];
              return ListTile(
                title: Text(provider['username'] ?? "Healthcare Provider"),
                subtitle: Text(provider['email'] ?? "No email available"),
                onTap: () {
                  onProviderSelected(provider['id']);
                },
              );
            },
          );
        }
      },
    );
  }
}
