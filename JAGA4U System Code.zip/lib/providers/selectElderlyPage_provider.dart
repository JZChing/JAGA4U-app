import 'package:flutter/material.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/caregiver/elderlyMedicationSchedule.dart';
import 'package:mae_assignment/screens/caregiver/reviewHealthData.dart';
import 'package:mae_assignment/screens/caregiver/viewElderlyLocation.dart';

class SelectElderlyPageProvider with ChangeNotifier {
  List<Map<String, String>> elderlyUsers = [];
  bool isLoading = true;
  final UserRepository _userRepository = UserRepository();
  
  Stream<List<Map<String, String>>> streamElderlyUsers(String caregiverID) {
    return _userRepository.streamAssociatedElderlyUsers(caregiverID);
  }

  Future<void> deleteElderlyUser(String caregiverID, String elderlyUserID, BuildContext context) async {
    try {
      await _userRepository.deleteAssociatedElderlyUser(caregiverID, elderlyUserID);

      await _userRepository.removeCaregiverFromElderlyUser(elderlyUserID, caregiverID);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Elderly user removed successfully.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to remove elderly user: $e")),
      );
    }
  }

  Future<void> addElderlyUser (
      String caregiverID, String username, BuildContext context) async {
    try {
      final elderlySnapshot = await _userRepository.getUserByUsername(username);
      final elderlyUserID = elderlySnapshot.id;
      final elderlyUsername = elderlySnapshot['username'];
      final role = elderlySnapshot['role'];

      // Check if the role is 'Elderly User'
      if (role == 'Elderly') {
        await _userRepository.addAssociatedElderlyUser (caregiverID, elderlyUserID, elderlyUsername);
        
        // Update the elderly user's document with the caregiver ID
        await _userRepository.updateElderlyUserWithCaregiverID(elderlyUserID, caregiverID);

        // Add to the local list and notify listeners
        elderlyUsers.add({'username': elderlyUsername, 'userID': elderlyUserID});
        notifyListeners(); // This updates the UI immediately
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("User  is not an elderly user.")),
        );
      }
    } catch (e) {
      print("Error adding elderly user: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("An error occurred: $e")),
      );
    }
  }

  void navigateToPage(
    BuildContext context,
    String elderlyID,
    String elderlyUsername,
    String destination,
    String caregiverID,
  ) {
    if (destination == 'healthData') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HealthDataPage(
            elderlyID: elderlyID,
            elderlyUsername: elderlyUsername,
            caregiverID: caregiverID,
          ),
        ),
      );
    } else if (destination == 'medicationSchedule') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MedicationSchedulePage(
            elderlyUserID: elderlyID,
            elderlyUserName: elderlyUsername,
            caregiverID: caregiverID,
          ),
        ),
      );
    }
    else if (destination == 'viewElderlyLocation') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ViewElderlyLocationPage(
            elderlyID: elderlyID,
            elderlyUsername: elderlyUsername,
          ),
        ),
      );
    }
  }
}
