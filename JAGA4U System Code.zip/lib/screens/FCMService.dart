import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:flutter/services.dart' show rootBundle;

class FCMService {
  final String projectId = 'mae-assignment-4d6ee';
  final String fcmUrl = 'https://fcm.googleapis.com/v1/projects/mae-assignment-4d6ee/messages:send';

  Future<void> sendPushNotification(String recipientFcmToken, String messageText, String title) async {
    final String serviceAccountJson = await rootBundle.loadString('assets/keys/service_account.json');
    final accountCredentials = ServiceAccountCredentials.fromJson(serviceAccountJson);
    final scopes = ['https://www.googleapis.com/auth/firebase.messaging'];

    final authClient = await clientViaServiceAccount(accountCredentials, scopes);
    final message = {
      'message': {
        'token': recipientFcmToken,
        'notification': {
          'title': title,
          'body': messageText,
        },
      },
    };

    try {
      final response = await authClient.post(
        Uri.parse(fcmUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(message),
      );

      if (response.statusCode == 200) {
        print('Notification sent successfully');
      } else {
        print('Failed to send notification: ${response.statusCode} ${response.body}');
      }
    } catch (e) {
      print('Error sending notification: $e');
    } finally {
      authClient.close();
    }
  }

  Future<String?> getRecipientFcmToken(String recipientId) async {
    final doc = await FirebaseFirestore.instance.collection('users').doc(recipientId).get();
    return doc.data()?['fcmToken'];
  }

}
