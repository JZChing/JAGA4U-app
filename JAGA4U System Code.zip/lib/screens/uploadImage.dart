import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';

Future<String?> uploadImage(Uint8List image, String userID) async {
  try {
    FirebaseStorage storage = FirebaseStorage.instance;
    Reference storageRef = storage.ref().child('profile_images/$userID.jpg');
    UploadTask uploadTask = storageRef.putData(image);

    TaskSnapshot taskSnapshot = await uploadTask;
    String downloadURL = await taskSnapshot.ref.getDownloadURL();  // Get the download URL
    return downloadURL; // Return the URL of the uploaded image
  } catch (e) {
    print('Error uploading image: $e');
    return null;
  }
}
