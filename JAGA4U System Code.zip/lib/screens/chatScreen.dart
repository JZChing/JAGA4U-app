import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mae_assignment/models/message.dart';
import 'package:mae_assignment/screens/FCMService.dart';
import 'package:mae_assignment/theming/app_text_style.dart';
import 'package:mae_assignment/widgets/custom_backArrow.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatefulWidget {
  final String chatID;
  final String senderID;
  final String recipientName;
  final String recipientID;

  ChatScreen({required this.chatID, required this.senderID, required this.recipientName, required this.recipientID});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final FCMService _fcmService = FCMService(); // Instantiate FCMService
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _markMessagesAsRead(); // Mark messages as read on opening the chat screen
    // Set a timer to mark messages as read every 10 seconds, for example
    _timer = Timer.periodic(Duration(seconds: 10), (timer) {
      _markMessagesAsRead();
    });
  }

  Future<void> _markMessagesAsRead() async {
    final messagesQuery = await FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatID)
        .collection('messages')
        .where('senderID', isEqualTo: widget.recipientID) // Only messages from the other user
        .where('isRead', isEqualTo: false) // Only unread messages
        .get();

    WriteBatch batch = FirebaseFirestore.instance.batch();

    for (var doc in messagesQuery.docs) {
      batch.update(doc.reference, {'isRead': true});
    }

    await batch.commit();
  }

  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;

    final message = Message(
      senderID: widget.senderID,
      recipientID: widget.chatID,
      messageText: _messageController.text.trim(),
      time: Timestamp.now(),
      isRead: false,
    );

    FirebaseFirestore.instance
        .collection('chats')
        .doc(widget.chatID)
        .collection('messages')
        .add(message.toFirestore());

    _messageController.clear();

    // Retrieve the recipient's FCM token
    final recipientFcmToken = await _fcmService.getRecipientFcmToken(widget.recipientID);

    // Send a push notification if the FCM token is available
    if (recipientFcmToken != null) {
      await _fcmService.sendPushNotification(
        recipientFcmToken,
        message.messageText,
        "New Message"
      );
    }
  }

  String _formatTimestamp(Timestamp timestamp) {
    DateTime dateTime = timestamp.toDate();
    return DateFormat('hh:mm a').format(dateTime); // Format as 'hour:minute AM/PM'
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    // Access the current theme (light/dark)
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    // Define colors based on the theme
    Color backgroundColor = isDarkMode ? Colors.black : Colors.white;
    Color textColor = isDarkMode ? Colors.white : Colors.black;

    // Define chat bubble colors
    Color senderBubbleColor = isDarkMode ? Colors.white : Colors.black;
    Color recipientBubbleColor = isDarkMode ? Colors.grey[800]! : Colors.grey[200]!;

    // Define message text color
    Color senderMessageTextColor = isDarkMode ? Colors.black : Colors.white; // Sender's message text color
    Color recipientMessageTextColor = isDarkMode ? Colors.white : Colors.black; // Recipient's message text color

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        leading: BackArrowWidget(size: screenWidth * 0.08, color: textColor),
        title: Text(
          widget.recipientName,
          style: GoogleFonts.lato(color: textColor, fontSize: screenWidth * 0.08),
        ),
        backgroundColor: isDarkMode ? Colors.black : AppColors.secondary, // Example secondary color
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('chats')
                  .doc(widget.chatID)
                  .collection('messages')
                  .orderBy('time', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text("No messages yet", style: TextStyle(color: textColor)));
                }

                // Mark messages as read whenever new messages are fetched
                _markMessagesAsRead();

                final messages = snapshot.data!.docs.map((doc) => Message.fromFirestore(doc)).toList();

                return ListView.builder(
                  reverse: true,
                  padding: EdgeInsets.all(16),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final isSender = message.senderID == widget.senderID;
              
                    return Align(
                      alignment: isSender ? Alignment.centerRight : Alignment.centerLeft,
                      child: Column(
                        crossAxisAlignment: isSender ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: isSender ? MainAxisAlignment.end : MainAxisAlignment.start,
                            children: [
                              Container(
                                constraints: BoxConstraints(maxWidth: screenWidth * 0.7),
                                margin: EdgeInsets.symmetric(vertical: 4),
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: isSender ? senderBubbleColor : recipientBubbleColor,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  message.messageText,
                                  style: TextStyle(
                                    color: isSender ? senderMessageTextColor : recipientMessageTextColor,
                                    fontSize: 18,
                                  ),
                                ),
                              ),
                              if (isSender)
                                Icon(
                                  message.isRead
                                      ? Icons.done_all  // Two ticks for read
                                      : Icons.done,     // One tick for sent but unread
                                  size: 16,
                                  color: message.isRead ? Colors.blue : Colors.grey,
                                ),
                            ],
                          ),
                          Padding(
                            padding: EdgeInsets.only(
                              top: 4,
                              left: isSender ? 0 : 8,
                              right: isSender ? 8 : 0,
                            ),
                            child: Text(
                              _formatTimestamp(message.time),
                              style: TextStyle(fontSize: 12, color: isDarkMode ? Colors.white54 : Colors.black54),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[700] : Colors.grey[400],
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _messageController,
                      maxLines: null,
                      style: TextStyle(fontSize: 16, color: textColor),
                      decoration: InputDecoration(
                        hintText: "Type a message",
                        border: InputBorder.none,
                        hintStyle: TextStyle(color: isDarkMode ? Colors.white54 : Colors.black54),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.secondary, // Example secondary color
                  ),
                  child: IconButton(
                    icon: Icon(Icons.send, color: AppColors.background),
                    onPressed: _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _messageController.dispose();
    super.dispose();
  }
}
