import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/providers/reviewHealthData_provider.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_Health_Metrics_fullPage.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_backArrow.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';

class HealthDataPage extends StatefulWidget {
  final String elderlyID;
  final String elderlyUsername;
  final String caregiverID;

  HealthDataPage({required this.elderlyID, required this.elderlyUsername, required this.caregiverID});

  @override
  _HealthDataPageState createState() => _HealthDataPageState();
}

class _HealthDataPageState extends State<HealthDataPage> {
  List<HealthData> healthMetrics = []; // Initialize an empty list for health metrics
  bool isLoading = true;
  int selectedIndex = 1;

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    handleBottomNavigationTap(context, index, widget.caregiverID);
  }

  @override
  Widget build(BuildContext context) {
    final healthDataProvider = Provider.of<HealthDataProvider>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        title: Text(widget.elderlyUsername, style: GoogleFonts.lato(color: Colors.black, fontSize: screenWidth * 0.07)),
        leading: BackArrowWidget(size: screenWidth * 0.1, color: Colors.black),
      ),
      body: StreamBuilder<List<HealthData>>(
        stream: healthDataProvider.healthDataStream(widget.elderlyID),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error fetching health data"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("No health data available"));
          }

          final healthMetrics = snapshot.data!;

          return SingleChildScrollView(
            padding: EdgeInsets.all(screenWidth * 0.04),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "Elderly People Health Log",
                  style: GoogleFonts.lato(
                      fontSize: screenWidth * 0.06,
                      fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: screenWidth * 0.05),
                SectionWithDivider(title: "Recent Health Metrics"),
                buildHealthDataTable(healthMetrics), // Passing health metrics to table
                ViewMoreButton(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => FullDataPage(elderlyID: widget.elderlyID),
                      ),
                    );

                    if (result != null) {
                      setState(() {
                        healthMetrics.clear();
                        healthMetrics.addAll(List<HealthData>.from(result));
                      });
                    }
                  },
                ),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget buildHealthDataTable(List<HealthData> healthMetrics) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: DataTable(
        columns: [
          DataColumn(label: Text('Date')),
          DataColumn(label: Text('Blood Pressure')),
          DataColumn(label: Text('Pulse Rate')),
        ],
        rows: healthMetrics.map((data) {
          return DataRow(cells: [
            DataCell(Text(data.time, overflow: TextOverflow.ellipsis)),
            DataCell(Text(data.bloodPressure.toString(), overflow: TextOverflow.ellipsis)),
            DataCell(Text(data.pulseRate.toString(), overflow: TextOverflow.ellipsis)),
          ]);
        }).toList(),
      ),
    );
  }

}

class SectionWithDivider extends StatelessWidget {
  final String title;

  SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            title,
            style: GoogleFonts.roboto(
                fontSize: screenWidth * 0.05,
                fontWeight: FontWeight.bold,
                color: AppColors.placeholder),
          ),
        ),
        Divider(thickness: 1, color: AppColors.placeholder),
      ],
    );
  }
}

class ViewMoreButton extends StatelessWidget {
  final VoidCallback onPressed;

  ViewMoreButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Align(
      alignment: Alignment.centerRight,
      child: TextButton(
        onPressed: onPressed,
        child: Text(
          "View More",
          style:
              TextStyle(color: AppColors.primary, fontSize: screenWidth * 0.04),
        ),
      ),
    );
  }
}

// Health data model
class HealthData {
  final String time;
  final double bloodPressure;
  final double pulseRate;

  HealthData({
    required this.time,
    required this.bloodPressure,
    required this.pulseRate,
  });
}