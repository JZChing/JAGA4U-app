// notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/providers/CaregiverAlert_provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/app_text_style.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/repositories/user_repository.dart';

class NotificationsScreen extends StatefulWidget {
  final String caregiverID;

  NotificationsScreen({required this.caregiverID});

  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  int selectedIndex = 3;

  @override
  void initState() {
    super.initState();
    Provider.of<CaregiverAlertProvider>(context, listen: false)
        .fetchAlertsCaregiver(widget.caregiverID);
  }

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    handleBottomNavigationTap(context, index, widget.caregiverID);
  }

  @override
  Widget build(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;
    double screenWidth = MediaQuery.of(context).size.width;
    final alertsProvider = Provider.of<CaregiverAlertProvider>(context);
    final alerts = alertsProvider.alerts;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        leading: Image.asset(
          'assets/mae emblem.png',
          height: 60,
        ),
        title: Text(
          "Alerts notifications",
          style: GoogleFonts.lato(
              color: Colors.black, fontSize: screenWidth * 0.06),
        ),
        centerTitle: true,
      ),
      body:
          alerts.isEmpty ? _buildEmptyState() : _buildAlertList(alertsProvider),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.notifications_none, size: 120, color: Colors.grey),
          SizedBox(height: 16),
          Text('No Alerts or Notifications',
              style: TextStyle(fontSize: 18, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildAlertList(CaregiverAlertProvider alertsProvider) {
    return ListView.builder(
      itemCount: alertsProvider.alerts.length,
      itemBuilder: (context, index) {
        final alert = alertsProvider.alerts[index];
        return FutureBuilder<String?>(
          future: UserRepository().getElderlyUserNameByID(alert.elderlyID),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            }
            if (!snapshot.hasData) {
              return Text("User not found");
            }

            final elderlyUserName = snapshot.data!;

            return Column(
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: Dismissible(
                    key: Key(alert.alertID),
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.only(left: 20),
                      child: Icon(Icons.delete, color: Colors.white),
                    ),
                    onDismissed: (_) {
                      alertsProvider.deleteAlert(index);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Alert deleted')),
                      );
                    },
                    child: Card(
                      color: Colors.grey[400],
                      elevation: 3,
                      margin: EdgeInsets.zero,
                      child: ListTile(
                        contentPadding:
                            EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                        title: Text(
                          'Alert: ${alert.alertStatus}',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Elderly User: $elderlyUserName',
                              style: TextStyle(color: Colors.grey[700]),
                            ),
                            Text(
                              'Date: ${alert.alertTime.toDate().toLocal().toString().split(' ')[0]}',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                            Text(
                              'Time: ${alert.alertTime.toDate().toLocal().toString().split(' ')[1].substring(0, 5)}',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ],
                        ),
                        trailing:
                            Icon(Icons.chevron_right, color: Colors.grey[600]),
                      ),
                    ),
                  ),
                ),
                if (index < alertsProvider.alerts.length - 1)
                  Divider(
                    thickness: 1,
                    color: Colors.grey[300],
                    indent: 20,
                    endIndent: 20,
                  ),
              ],
            );
          },
        );
      },
    );
  }
}
