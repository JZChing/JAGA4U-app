import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewElderlyLocationPage extends StatefulWidget {
  final String elderlyID;
  final String elderlyUsername;

  ViewElderlyLocationPage({required this.elderlyID, required this.elderlyUsername});

  @override
  _ViewElderlyLocationPageState createState() => _ViewElderlyLocationPageState();
}

class _ViewElderlyLocationPageState extends State<ViewElderlyLocationPage> {
  GoogleMapController? mapController;
  LatLng? elderlyLocation;
  String locationMessage = 'Loading location...';

  @override
  void initState() {
    super.initState();
    _getElderlyLocationStream();
  }

  // Fetch live location updates from Firestore
  void _getElderlyLocationStream() {
    FirebaseFirestore.instance
        .collection('locations')
        .doc(widget.elderlyID)
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists) {
        final data = snapshot.data()!;
        setState(() {
          elderlyLocation = LatLng(data['latitude'], data['longitude']);
          locationMessage = 'Latitude: ${data['latitude']}, Longitude: ${data['longitude']}';

          // Move the map camera to the new location
          if (mapController != null) {
            mapController!.animateCamera(
              CameraUpdate.newCameraPosition(
                CameraPosition(
                  target: elderlyLocation!,
                  zoom: 17, // Adjust zoom to better fit the elderly location
                ),
              ),
            );
          }
        });
      } else {
        setState(() {
          locationMessage = 'Location data not available.';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text('${widget.elderlyUsername}\'s Location'), // Display the elderly name here
          backgroundColor: const Color(0xFFA9DFBF),
          centerTitle: true,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(locationMessage),
              SizedBox(height: 20),
              Container(
                height: 400,
                width: double.infinity,
                child: elderlyLocation == null
                    ? Center(child: CircularProgressIndicator())
                    : GoogleMap(
                        onMapCreated: (controller) {
                          mapController = controller;
                          // Ensure camera moves to location on map creation
                          if (elderlyLocation != null) {
                            mapController!.animateCamera(
                              CameraUpdate.newCameraPosition(
                                CameraPosition(
                                  target: elderlyLocation!,
                                  zoom: 18,
                                ),
                              ),
                            );
                          }
                        },
                        initialCameraPosition: CameraPosition(
                          target: elderlyLocation ?? LatLng(0, 0),
                          zoom: 17,
                        ),
                        markers: {
                          if (elderlyLocation != null)
                            Marker(
                              markerId: MarkerId('elderlyLocation'),
                              position: elderlyLocation!,
                            ),
                        },
                      ),
              ),
            ],
          ),
        ),
      );
}

