import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/providers/selectHealthcareProvider_provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';

class SelectHealthcareProviderPage extends StatefulWidget {
  final String caregiverID;

  SelectHealthcareProviderPage({required this.caregiverID});

  @override
  _SelectHealthcareProviderPageState createState() => _SelectHealthcareProviderPageState();
}

class _SelectHealthcareProviderPageState extends State<SelectHealthcareProviderPage> {
  int selectedIndex = 4;

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    handleBottomNavigationTap(context, index, widget.caregiverID);
  }
  
  void showAddHealthcareProviderDialog() {
    TextEditingController usernameController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add Healthcare Provider"),
        content: TextField(
          controller: usernameController,
          decoration: InputDecoration(labelText: "Enter Healthcare Provider username"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              try {
              // Call the method to add the HealthcareProvider
              await Provider.of<SelectHealthcareProviderPageProvider>(context, listen: false)
                  .addHealthcareProvider (
                widget.caregiverID,
                usernameController.text,
                context,
              );

              // Close the dialog after adding
              Navigator.of(context).pop();
            } catch (e) {
              // Handle the error (optional)
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Failed to add Healthcare Provider: $e')),
              );
            }
          },
          child: Text("Add"),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        leading: Image.asset(
          'assets/mae emblem.png',
          height: 60,
        ),
        title: Text(
          "Chat with Healthcare Provider",
          style: GoogleFonts.lato(color: Colors.black, fontSize: screenWidth * 0.05),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.person_add, size: screenWidth * 0.1, color: Colors.black),
            onPressed: showAddHealthcareProviderDialog,
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(screenWidth * 0.05),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Select Healthcare Provider to Chat",
              style: GoogleFonts.lato(color: Colors.black, fontSize: screenWidth * 0.05),
            ),
            SizedBox(height: screenWidth * 0.05), // Add spacing below the text
            Expanded(
              child: StreamBuilder<List<Map<String, String>>>(
                stream: Provider.of<SelectHealthcareProviderPageProvider>(context)
                    .streamHealthcareProviders(widget.caregiverID),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text("Error loading Healthcare Providers."));
                  }
                  final HealthcareProviders = snapshot.data ?? [];
                  if (HealthcareProviders.isEmpty) {
                    return Center(
                      child: Text(
                        "No Healthcare Providers added.",
                        style: GoogleFonts.lato(
                            color: Colors.black, fontSize: screenWidth * 0.045),
                      ),
                    );
                  }
                  return ListView.builder(
                    itemCount: HealthcareProviders.length,
                    itemBuilder: (context, index) {
                      final HealthcareProvider = HealthcareProviders[index];
                      return _buildHealthcareProviderButton(context, HealthcareProvider);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
              currentIndex: selectedIndex,
              fontSize: fontSize,
              onTap: _onItemTapped,
            ),
    );
  }


  Widget _buildHealthcareProviderButton(
      BuildContext context, Map<String, String> HealthcareProvider) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Padding(
      padding: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
      child: ElevatedButton(
        onPressed: () {
          Provider.of<SelectHealthcareProviderPageProvider>(context, listen: false)
            .navigateToPage(
          context,
          HealthcareProvider['userID']!,
          HealthcareProvider['username']!,
          widget.caregiverID, // Pass caregiverID from widget
        );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.grey[300],
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CircleAvatar(
              backgroundColor: Colors.grey[400],
              radius: screenWidth * 0.06,
              child: Icon(Icons.person,
                  color: Colors.white, size: screenWidth * 0.05),
            ),
            SizedBox(width: screenWidth * 0.04),
            Expanded(
              child: Text(HealthcareProvider['username']!,
                  style: GoogleFonts.lato(
                      color: Colors.black, fontSize: screenWidth * 0.045)),
            ),
            Row(
            children: [
              IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  try {
                    await Provider.of<SelectHealthcareProviderPageProvider>(context, listen: false)
                        .deleteHealthcareProvider(
                      widget.caregiverID,
                      HealthcareProvider['userID']!,
                      context,
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${HealthcareProvider['username']} removed successfully')),
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to remove elderly user: $e')),
                    );
                  }
                },
              ),
              Icon(Icons.arrow_forward_ios, color: Colors.black),
            ],
            ),
          ],
        ),
      ),
    );
  }
}
