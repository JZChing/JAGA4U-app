import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/providers/elderlyMedicationSchedule_provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_backArrow.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';

class MedicationSchedulePage extends StatelessWidget {
  final String elderlyUserID;
  final String elderlyUserName;
  final String caregiverID;

  MedicationSchedulePage({
    required this.elderlyUserID,
    required this.elderlyUserName,
    required this.caregiverID,
  });

  @override
  Widget build(BuildContext context) {
    final medicationProvider = Provider.of<MedicationProvider>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        leading: BackArrowWidget(size: screenWidth * 0.1, color: Colors.black),
        title: Text(
          'Medication Schedule',
          style: GoogleFonts.lato(
              color: Colors.black, fontSize: screenWidth * 0.07),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.add, size: screenWidth * 0.1, color: Colors.black),
            onPressed: () =>
                medicationProvider.addMedication(context, elderlyUserID),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Elderly User: $elderlyUserName',
              style: TextStyle(
                  fontSize: screenWidth * 0.05, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Medication>>(
              stream: medicationProvider.medicationsStream(elderlyUserID),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(child: Text("No medications scheduled."));
                }

                final medications = snapshot.data!;

                return Padding(
                  padding: EdgeInsets.all(16.0),
                  child: ListView.builder(
                    itemCount: medications.length,
                    itemBuilder: (context, index) {
                      var medication = medications[index];

                      return Padding(
                        padding: EdgeInsets.only(bottom: 8.0),
                        child: Card(
                          color: Colors.grey[300],
                          child: Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Medication Type: ${medication.medicationType}',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(height: 4.0),
                                    Text(
                                      'Date: ${medication.dateTime.toLocal().toString().split(' ')[0]}',
                                      style: TextStyle(fontSize: 14),
                                    ),
                                    Text(
                                      'Time: ${medication.dateTime.toLocal().toString().split(' ')[1].substring(0, 5)}',
                                      style: TextStyle(fontSize: 14),
                                    ),
                                    Text(
                                      'Status: ${medication.medicationStatus}',
                                      style: TextStyle(fontSize: 14),
                                    ),
                                  ],
                                ),
                                IconButton(
                                  icon: Icon(Icons.delete, color: Colors.red),
                                  onPressed: () {
                                    // Call the delete function in the provider
                                    medicationProvider.deleteMedication(
                                        elderlyUserID, medication.medicationID);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: medicationProvider.selectedIndex,
        fontSize: fontSize,
        onTap: (index) =>
            medicationProvider.onItemTapped(context, index, caregiverID),
      ),
    );
  }
}
