import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/providers/selectElderlyPage_provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';

class SelectElderlyPage extends StatefulWidget {
  final String caregiverID;
  final String destination;

  SelectElderlyPage({required this.caregiverID, required this.destination});

  @override
  _SelectElderlyPageState createState() => _SelectElderlyPageState();
}

class _SelectElderlyPageState extends State<SelectElderlyPage> {
  int selectedIndex = 0;
  @override
  void initState() {
    super.initState();
    // Set the initial selectedIndex based on widget.destination
    if (widget.destination == 'healthData') {
      selectedIndex = 1;
    } else if (widget.destination == 'medicationSchedule') {
      selectedIndex = 2;
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    handleBottomNavigationTap(context, index, widget.caregiverID);
  }
  
  void showAddElderlyDialog() {
    TextEditingController usernameController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add Elderly User"),
        content: TextField(
          controller: usernameController,
          decoration: InputDecoration(labelText: "Enter elderly username"),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () async {
              try {
              // Call the method to add the elderly user
              await Provider.of<SelectElderlyPageProvider>(context, listen: false)
                  .addElderlyUser (
                widget.caregiverID,
                usernameController.text,
                context,
              );

              // Close the dialog after adding
              Navigator.of(context).pop();
            } catch (e) {
              // Handle the error (optional)
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Failed to add elderly user: $e')),
              );
            }
          },
          child: Text("Add"),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    String appBarTitle = widget.destination == "healthData"
        ? "Health Data"
        : widget.destination == "medicationSchedule"
            ? "Medication Schedule"
            : widget.destination == "viewElderlyLocation"
                ? "Elderly Location"
                : "Select Elderly";

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        leading: Image.asset(
          'assets/mae emblem.png',
          height: 60,
        ),
        title: Text(
          appBarTitle,
          style: GoogleFonts.lato(color: Colors.black, fontSize: screenWidth * 0.07),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.person_add, size: screenWidth * 0.1, color: Colors.black),
            onPressed: showAddElderlyDialog,
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(screenWidth * 0.05),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Select Elderly User",
              style: GoogleFonts.lato(color: Colors.black, fontSize: screenWidth * 0.05),
            ),
            SizedBox(height: screenWidth * 0.05),
            Expanded(
              child: StreamBuilder<List<Map<String, String>>>(
                stream: Provider.of<SelectElderlyPageProvider>(context)
                    .streamElderlyUsers(widget.caregiverID),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text("Error loading elderly users."));
                  }
                  final elderlyUsers = snapshot.data ?? [];
                  if (elderlyUsers.isEmpty) {
                    return Center(
                      child: Text(
                        "No elderly users added.",
                        style: GoogleFonts.lato(
                            color: Colors.black, fontSize: screenWidth * 0.045),
                      ),
                    );
                  }
                  return ListView.builder(
                    itemCount: elderlyUsers.length,
                    itemBuilder: (context, index) {
                      final elderly = elderlyUsers[index];
                      return _buildElderlyButton(context, elderly);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }


  Widget _buildElderlyButton(
      BuildContext context, Map<String, String> elderly) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Padding(
      padding: EdgeInsets.symmetric(vertical: screenWidth * 0.02),
      child: ElevatedButton(
        onPressed: () {
          Provider.of<SelectElderlyPageProvider>(context, listen: false)
            .navigateToPage(
          context,
          elderly['userID']!,
          elderly['username']!,
          widget.destination, // Pass the destination from widget
          widget.caregiverID, // Pass caregiverID from widget
        );
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.grey[300],
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            CircleAvatar(
              backgroundColor: Colors.grey[400],
              radius: screenWidth * 0.06,
              child: Icon(Icons.person,
                  color: Colors.white, size: screenWidth * 0.05),
            ),
            SizedBox(width: screenWidth * 0.04),
            Expanded(
              child: Text(elderly['username']!,
                  style: GoogleFonts.lato(
                      color: Colors.black, fontSize: screenWidth * 0.045)),
            ),
            Row(
            children: [
              IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  try {
                    await Provider.of<SelectElderlyPageProvider>(context, listen: false)
                        .deleteElderlyUser(
                      widget.caregiverID,
                      elderly['userID']!,
                      context,
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('${elderly['username']} removed successfully')),
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to remove elderly user: $e')),
                    );
                  }
                },
              ),
              Icon(Icons.arrow_forward_ios, color: Colors.black),
            ],
            ),
          ],
        ),
      ),
    );
  }
}
