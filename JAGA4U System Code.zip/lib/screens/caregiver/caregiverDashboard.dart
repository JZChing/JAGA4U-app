import 'package:flutter/material.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/providers/caregiverDashboardTable_provider.dart';
import 'package:mae_assignment/providers/selectElderlyPage_provider.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/caregiver/selectElderly.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:mae_assignment/widgets/custom_caregiverNavBar.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/theme_provider.dart'; // Ensure ThemeProvider is imported
import 'package:mae_assignment/screens/login.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_appBar.dart';

class CaregiverDashboardPage extends StatefulWidget {
  final String userID;

  CaregiverDashboardPage({required this.userID});
  @override
  CaregiverDashboardPageState createState() => CaregiverDashboardPageState();
}

class CaregiverDashboardPageState extends State<CaregiverDashboardPage> {
  final UserRepository userRepository = UserRepository();
  int selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });

    handleBottomNavigationTap(context, index, widget.userID);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AssociatedMedicationProvider>(context, listen: false)
          .fetchTodaysMedicationSchedule(widget.userID);
    });
    Provider.of<AssociatedMedicationProvider>(context, listen: false)
        .fetchMedicationsWithUserNames(widget.userID);
  }

  @override
  Widget build(BuildContext context) {
    // Access dynamic font size from ThemeProvider
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Welcome Caregiver!",
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontSize: fontSize + 6, // Adjust font size as needed
                    fontWeight: FontWeight.bold,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.account_circle, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProfilePage(
                          userID: widget.userID,
                        ),
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.settings, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SettingPage(
                                userID: '[userID]',
                              )),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.logout, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 16.0),
            _SectionWithDivider(
              title: "Today's Elderly Medication Schedule",
            ),
            Consumer<AssociatedMedicationProvider>(
              builder: (context, medicationProvider, child) {
                List<Map<String, dynamic>> medicationsWithNames = medicationProvider.medicationsWithNames;

                if (medicationsWithNames.isEmpty) {
                  return Center(child: Text("No medications scheduled for today."));
                }

                return ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: medicationsWithNames.length,
                  itemBuilder: (context, index) {
                    final medicationData = medicationsWithNames[index];
                    final Medication medication = medicationData['medication'];
                    final String elderlyUserName = medicationData['userName'];

                    return ListTile(
                      title: Text("$elderlyUserName - ${medication.medicationType} - ${medication.dosage}"),
                      subtitle: Text("Status: ${medication.medicationStatus}"),
                      trailing: Text(
                        "${medication.dateTime.hour}:${medication.dateTime.minute}",
                        style: TextStyle(color: Colors.grey),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChangeNotifierProvider(
              create: (_) => SelectElderlyPageProvider(),
              child: SelectElderlyPage(
                caregiverID: widget.userID,
                destination: 'viewElderlyLocation',
              ),
            ),
            ),
          );
        },
        label: Text("Elderly Location", style: AppTextStyles.buttonText),
        icon: Icon(Icons.location_pin, color: AppColors.secondary),
        backgroundColor: Colors.black,
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }
}

class _SectionWithDivider extends StatelessWidget {
  final String title;

  _SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        Divider(thickness: 1, color: Colors.grey),
      ],
    );
  }
}
