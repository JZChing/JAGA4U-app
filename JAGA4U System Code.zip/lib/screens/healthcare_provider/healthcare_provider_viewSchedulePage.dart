import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/theming/app_text_style.dart';
import 'package:mae_assignment/widgets/custom_backArrow.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/repositories/appointment_repository.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/widgets/custom_healthcare_providerNavBar.dart';

class ViewScheduleAppointmentsPage extends StatefulWidget {
  final String providerID;

  ViewScheduleAppointmentsPage({required this.providerID});

  @override
  _ViewScheduleAppointmentsPageState createState() =>
      _ViewScheduleAppointmentsPageState();
}

class _ViewScheduleAppointmentsPageState
    extends State<ViewScheduleAppointmentsPage> {
  int selectedIndex = 3;

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });
    healthcareProviderBottomNavigationBar(context, index, widget.providerID);
  }

  @override
  Widget build(BuildContext context) {
    final appointmentRepository = Provider.of<AppointmentRepository>(context);
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        title: Text("Schedule Appointments",
            style: GoogleFonts.lato(
                color: Colors.black, fontSize: screenWidth * 0.06)),
        leading: BackArrowWidget(size: screenWidth * 0.1, color: Colors.black),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: appointmentRepository.getAppointmentsWithElderlyUsername(widget.providerID),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error fetching appointments"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("No appointments scheduled"));
          }

          final appointmentsWithUsername = snapshot.data!;

          return ListView.builder(
            itemCount: appointmentsWithUsername.length,
            itemBuilder: (context, index) {
              final appointmentData = appointmentsWithUsername[index];
              final appointment = appointmentData['appointment'];
              final elderlyUsername = appointmentData['elderlyUsername'];

              return Card(
                margin: EdgeInsets.all(screenWidth * 0.02),
                child: ListTile(
                  title: Text(
                    "Appointment with $elderlyUsername on ${appointment.appointmentDateTime.toDate().toLocal().toString().split(' ')[0]}, "
                    "${appointment.appointmentDateTime.toDate().toLocal().toString().split(' ')[1].substring(0, 5)}",
                  ),
                  subtitle: Text("Status: ${appointment.status}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DropdownButton<String>(
                        value: appointment.status,
                        items: <String>['scheduled', 'completed', 'canceled']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (newStatus) {
                          if (newStatus != null) {
                            appointmentRepository.updateAppointmentStatus(
                                appointment.appointmentID, newStatus);
                          }
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          // Confirm before deleting
                          bool confirmDelete = await showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text("Delete Appointment"),
                              content: Text(
                                  "Are you sure you want to delete this appointment?"),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.of(context).pop(false),
                                  child: Text("Cancel"),
                                ),
                                TextButton(
                                  onPressed: () => Navigator.of(context).pop(true),
                                  child: Text("Delete"),
                                ),
                              ],
                            ),
                          );

                          if (confirmDelete) {
                            await appointmentRepository
                                .deleteAppointment(appointment.appointmentID);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      bottomNavigationBar: CustomHealthcareProviderNavBar(
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }
}
