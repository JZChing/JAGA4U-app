import 'package:flutter/material.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/providers/caregiverDashboardTable_provider.dart';
import 'package:mae_assignment/screens/healthcare_provider/healthcare_provider_chatList.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:mae_assignment/widgets/custom_healthcare_providerNavBar.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/screens/login.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_appBar.dart';

class HealthcareProviderDashboardPage extends StatefulWidget {
  final String userID;

  HealthcareProviderDashboardPage({required this.userID});

  @override
  HealthcareProviderDashboardPageState createState() =>
      HealthcareProviderDashboardPageState();
}

class HealthcareProviderDashboardPageState
    extends State<HealthcareProviderDashboardPage> {
  int selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      selectedIndex = index;
    });

    healthcareProviderBottomNavigationBar(context, index, widget.userID);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<AssociatedMedicationProvider>(context, listen: false)
          .fetchTodaysMedicationSchedule(widget.userID);
    });
    Provider.of<AssociatedMedicationProvider>(context, listen: false)
        .fetchMedicationsWithUserNames(widget.userID);
  }

  @override
  Widget build(BuildContext context) {
    // Access dynamic font size from ThemeProvider
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Welcome Healthcare Provider!",
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontSize: fontSize + 6, // Adjust font size as needed
                    fontWeight: FontWeight.bold,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 16.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.account_circle, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProfilePage(
                          userID: widget.userID,
                        ),
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.settings, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SettingPage(
                                userID: '[userID]',
                              )),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.logout, size: fontSize + 16),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: 16.0),
            _SectionWithDivider(
              title: "Today's Patient Medication Schedule", // Changed title
            ),
            Consumer<AssociatedMedicationProvider>(
              builder: (context, medicationProvider, child) {
                List<Map<String, dynamic>> medicationsWithNames = medicationProvider.medicationsWithNames;

                if (medicationsWithNames.isEmpty) {
                  return Center(child: Text("No medications scheduled for today."));
                }

                return ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: medicationsWithNames.length,
                  itemBuilder: (context, index) {
                    final medicationData = medicationsWithNames[index];
                    final Medication medication = medicationData['medication'];
                    final String elderlyUserName = medicationData['userName'];

                    return ListTile(
                      title: Text("$elderlyUserName - ${medication.medicationType} - ${medication.dosage}"),
                      subtitle: Text("Status: ${medication.medicationStatus}"),
                      trailing: Text(
                        "${medication.dateTime.hour}:${medication.dateTime.minute}",
                        style: TextStyle(color: Colors.grey),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Navigate to the chat list page
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatListPage(
                providerID: widget.userID,
              ),
            ),
          );
        },
        label: Text("Message", style: AppTextStyles.buttonText),
        icon: Icon(Icons.chat, color: AppColors.secondary),
        backgroundColor: Colors.black,
      ),
      bottomNavigationBar: CustomHealthcareProviderNavBar(
        // Updated navbar
        currentIndex: selectedIndex,
        fontSize: fontSize,
        onTap: _onItemTapped,
      ),
    );
  }
}

class _SectionWithDivider extends StatelessWidget {
  final String title;

  _SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        Divider(thickness: 1, color: Colors.grey),
      ],
    );
  }
}
