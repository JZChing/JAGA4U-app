// lib/auth_service.dart
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  /// Save or update the user's FCM token in Firestore
  Future<void> saveUserToken(String userId) async {
    // Request the FCM token for the user
    String? token = await _firebaseMessaging.getToken();
    if (token != null) {
      // Save the token in Firestore under the user's document
      await FirebaseFirestore.instance.collection('users').doc(userId).set({
        'fcmToken': token,
      }, SetOptions(merge: true)); // Use merge to avoid overwriting other fields
    }
  }

  /// Listen for token refresh and update Firestore when it changes
  void setupTokenRefresh(String userId) {
    _firebaseMessaging.onTokenRefresh.listen((newToken) async {
      await FirebaseFirestore.instance.collection('users').doc(userId).set({
        'fcmToken': newToken,
      }, SetOptions(merge: true));
    });
  }
}