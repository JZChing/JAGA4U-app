import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mae_assignment/models/user.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/screens/pickImage.dart';
import 'package:path_provider/path_provider.dart'; // for local storage
import 'package:path/path.dart' as path;

class EditProfilePage extends StatefulWidget {
  final String userID;
  final UserRepository userRepository;

  EditProfilePage({required this.userID, required this.userRepository});

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController usernameController;
  late TextEditingController contactInfoController;
  Uint8List? _image;

  @override
  void initState() {
    super.initState();
    usernameController = TextEditingController();
    contactInfoController = TextEditingController();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    UserData? user = await widget.userRepository.getUserByID(widget.userID);
    if (user != null) {
      setState(() {
        usernameController.text = user.username;
        contactInfoController.text = user.contactInfo;
      });
    }
  }

  Future<String> _saveImageLocally(Uint8List imageBytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final imagePath = path.join(directory.path, 'profile_pictures', '${widget.userID}.png');
    final imageFile = File(imagePath);
    await imageFile.create(recursive: true); // Ensure directory exists
    await imageFile.writeAsBytes(imageBytes);
    return imagePath;
  }

  Future<void> saveProfileChanges() async {
    if (_image != null) {
      // Save image locally
      String imagePath = await _saveImageLocally(_image!);
      print("Image saved at: $imagePath");
    }

    // Update other user data
    UserData? existingUser = await widget.userRepository.getUserByID(widget.userID);

    if (existingUser != null) {
      await widget.userRepository.updateUser(UserData(
        userID: widget.userID,
        username: usernameController.text.isNotEmpty ? usernameController.text : existingUser.username,
        contactInfo: contactInfoController.text.isNotEmpty ? contactInfoController.text : existingUser.contactInfo,
        profileImage: 'assets/profile_pictures/${widget.userID}.png', // Update to reflect the new local image
        password: existingUser.password,
        email: existingUser.email,
        role: existingUser.role,
        createdAt: existingUser.createdAt,
      ));

      Navigator.pop(context, true); // Pass a flag to refresh the previous screen
    }
  }

  // Method to pick an image from the gallery
  void selectImage() async {
    Uint8List? img = await pickImage(ImageSource.gallery);
    if (img != null) {
      setState(() {
        _image = img;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                _image != null
                    ? CircleAvatar(radius: 60, backgroundImage: MemoryImage(_image!))
                    : CircleAvatar(
                        radius: 60,
                        backgroundImage: AssetImage('assets/profile_pictures/${widget.userID}.png'),
                      ),
                IconButton(
                  icon: Icon(Icons.add_a_photo, color: Colors.blue),
                  onPressed: selectImage,
                ),
              ],
            ),
            SizedBox(height: 16.0),

            TextField(
              controller: usernameController,
              decoration: InputDecoration(labelText: "Username"),
            ),
            SizedBox(height: 16.0),

            TextField(
              controller: contactInfoController,
              decoration: InputDecoration(labelText: "Contact Info"),
            ),
            SizedBox(height: 16.0),

            ElevatedButton(
              onPressed: saveProfileChanges,
              child: Text("Save Changes"),
            ),
          ],
        ),
      ),
    );
  }
}
