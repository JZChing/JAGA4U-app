import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/widgets/custom_backArrow.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:vibration/vibration.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingPage extends StatefulWidget {
  final String userID;

  SettingPage({required this.userID});

  @override
  _SettingPageState createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  // Accessibility settings
  bool darkmode = false;

  // Notification preferences
  bool audioNotification = true;
  bool vibrationNotification = true;

  // AudioPlayer instance for playing sound
  final AudioPlayer _audioPlayer = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _loadSettings(); // Load settings when the page is opened
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  // Load settings from SharedPreferences
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      darkmode = prefs.getBool('darkmode') ?? false;
      audioNotification = prefs.getBool('audioNotification') ?? true;
      vibrationNotification = prefs.getBool('vibrationNotification') ?? true;

      // Apply dark mode if enabled
      Provider.of<ThemeProvider>(context, listen: false).toggleTheme(darkmode);
    });
  }

  // Save a specific setting to SharedPreferences
  Future<void> _saveSetting(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  // Function to trigger vibration
  void triggerVibration() async {
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate();
    }
  }

  // Function to play notification sound
  void playSound() async {
    await _audioPlayer.play(AssetSource("assets/beep.mp3"));
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        title: Text("Setting", style: TextStyle(fontSize: fontSize + 2)),
        leading: BackArrowWidget(size: screenWidth * 0.1, color: Colors.black),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Accessibility Settings
            Text(
              "Accessibility Settings",
              style: TextStyle(fontSize: fontSize + 4, fontWeight: FontWeight.bold),
            ),
            SwitchListTile(
              title: Text("Dark Mode", style: TextStyle(fontSize: fontSize)),
              value: darkmode,
              onChanged: (value) {
                setState(() {
                  darkmode = value;
                  Provider.of<ThemeProvider>(context, listen: false).toggleTheme(darkmode);
                });
                _saveSetting('darkmode', darkmode); // Save dark mode setting
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("Font Size", style: TextStyle(fontSize: fontSize)),
                Icon(Icons.text_fields, size: fontSize),
              ],
            ),
            Slider(
              value: fontSize,
              min: 12,
              max: 24,
              divisions: 6,
              label: fontSize.round().toString(),
              onChanged: (value) {
                Provider.of<ThemeProvider>(context, listen: false).setFontSize(value);
              },
            ),
            Divider(),

            // Notification Preferences
            Text(
              "Notification Preferences",
              style: TextStyle(fontSize: fontSize + 4, fontWeight: FontWeight.bold),
            ),
            SwitchListTile(
              title: Text("Audio", style: TextStyle(fontSize: fontSize)),
              value: audioNotification,
              onChanged: (value) {
                setState(() {
                  audioNotification = value;
                  if (audioNotification) playSound();
                });
                _saveSetting('audioNotification', audioNotification); // Save audio setting
              },
            ),
            SwitchListTile(
              title: Text("Vibration", style: TextStyle(fontSize: fontSize)),
              value: vibrationNotification,
              onChanged: (value) {
                setState(() {
                  vibrationNotification = value;
                  if (vibrationNotification) triggerVibration();
                });
                _saveSetting('vibrationNotification', vibrationNotification); // Save vibration setting
              },
            ),
          ],
        ),
      ),
    );
  }
}
