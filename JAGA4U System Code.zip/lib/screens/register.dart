import 'package:flutter/material.dart';
import 'package:mae_assignment/providers/register_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>(); // Form key for validation
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController contactInfoController = TextEditingController();

  // Role dropdown options
  final List<String> roles = ['Elderly', 'Caregiver', 'Healthcare Provider'];
  String? selectedRole;

  RegisterProvider registerFunctions = RegisterProvider();

  // Regex for basic phone number validation
  final RegExp phoneRegex = RegExp(r'^\+[0-9]{10,15}$');

  @override
  void initState() {
    super.initState();
    // Initialize with the '+' character
    contactInfoController.text = '+60';
    // Set the initial cursor position to the end of the text
    contactInfoController.selection = TextSelection.fromPosition(
      TextPosition(offset: contactInfoController.text.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.placeholder),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
          child: SingleChildScrollView(
            child: Transform.translate(
              offset: Offset(0, -screenHeight * 0.05),
              child: Form(
                key: _formKey, // Form key for validation
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/mae emblem.png',
                      width: screenWidth * 0.3,
                      height: screenWidth * 0.3,
                      fit: BoxFit.contain,
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    Text(
                      'JAGA4U',
                      style: TextStyle(
                        fontSize: screenWidth * 0.08,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primary,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.01),
                    Text(
                      'Register',
                      style: AppTextStyles.headerText,
                    ),
                    SizedBox(height: screenHeight * 0.04),
                    // Username field with validation
                    TextFormField(
                      controller: usernameController,
                      decoration: InputDecoration(
                        labelText: 'Username',
                        labelStyle: AppTextStyles.placeholderText,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Username is required';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    // Password field with validation
                    TextFormField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: AppTextStyles.placeholderText,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (value) {
                        if (value == null || value.length < 6) {
                          return 'Password must be at least 6 characters';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    // Email field with validation
                    TextFormField(
                      controller: emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        labelStyle: AppTextStyles.placeholderText,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Email is required';
                        } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+')
                            .hasMatch(value)) {
                          return 'Please enter a valid email';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    // Role dropdown with validation
                    DropdownButtonFormField<String>(
                      value: selectedRole,
                      items: roles.map((role) {
                        return DropdownMenuItem(
                          value: role,
                          child: Text(role),
                        );
                      }).toList(),
                      decoration: InputDecoration(
                        labelText: 'Role',
                        labelStyle: AppTextStyles.placeholderText,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      onChanged: (value) {
                        setState(() {
                          selectedRole = value;
                        });
                      },
                      validator: (value) =>
                          value == null ? 'Please select a role' : null,
                    ),
                    SizedBox(height: screenHeight * 0.02),
                    // Phone number field with validation
                    TextFormField(
                      controller: contactInfoController,
                      decoration: InputDecoration(
                        labelText: 'Phone number',
                        labelStyle: TextStyle(
                            color: Colors
                                .grey), // Replace with your AppTextStyles.placeholderText
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Phone number is required';
                        } else if (!phoneRegex.hasMatch(value)) {
                          return 'Please enter a valid phone number (e.g. +60111088888)';
                        }
                        return null;
                      },
                      onChanged: (value) {
                        // Ensure that the first character is always '+'
                        if (!value.startsWith('+60')) {
                          contactInfoController.text = '+60';
                          contactInfoController.selection =
                              TextSelection.fromPosition(
                            TextPosition(
                                offset: contactInfoController.text.length),
                          );
                        }
                      },
                    ),
                    SizedBox(height: screenHeight * 0.04),
                    // Register button
                    SizedBox(
                      width: double.infinity,
                      height: screenHeight * 0.06,
                      child: ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            registerFunctions.registerUser(
                              context,
                              username: usernameController.text,
                              password: passwordController.text,
                              email: emailController.text,
                              contactInfo: contactInfoController.text,
                              selectedRole: selectedRole,
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          textStyle: AppTextStyles.buttonText.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text(
                          'Register',
                          style: AppTextStyles.bodyText1.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
