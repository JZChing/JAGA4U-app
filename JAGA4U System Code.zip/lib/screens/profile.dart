import 'package:flutter/material.dart';
import 'package:mae_assignment/models/user.dart';
import 'package:mae_assignment/constants/placeholderURL.dart';
import 'package:mae_assignment/screens/edit_profile.dart';
import 'package:mae_assignment/repositories/user_repository.dart';
import 'package:mae_assignment/theming/app_text_style.dart';

class ProfilePage extends StatefulWidget {
  final String userID;

  ProfilePage({required this.userID});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final UserRepository userRepository = UserRepository();
  late Future<UserData?> userFuture;
  late ImageProvider<Object> _imageProvider;

  @override
  void initState() {
    super.initState();
    refreshProfile();
    // Initialize with the local asset image
    _imageProvider = AssetImage('assets/profile_pictures/${widget.userID}.png');
  }

  void refreshProfile() {
    setState(() {
      userFuture = userRepository.getUserByID(widget.userID);
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    
    return Scaffold(
      appBar: AppBar(
        title: Text("User Profile"),
      ),
      body: FutureBuilder<UserData?>(
        future: userFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || snapshot.data == null) {
            return Center(child: Text("Failed to load user data"));
          }

          // Load user data
          UserData user = snapshot.data!;

          return SingleChildScrollView(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Profile image
                CircleAvatar(
                  radius: 60,
                  backgroundImage: _imageProvider,
                  onBackgroundImageError: (exception, stackTrace) {
                    print("Error loading image: $exception"); // Log error for debugging
                    setState(() {
                      _imageProvider = NetworkImage(userPlaceholder);
                    });
                  },
                ),
                SizedBox(height: 16.0),

                // Username
                Text(
                  user.username,
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8.0),

                // Email
                Text(
                  user.email,
                  style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                ),
                SizedBox(height: 16.0),

                // Additional Info
                buildInfoRow("Role:", user.role),
                buildInfoRow("Contact Info:", user.contactInfo),
                SizedBox(height: 32.0), // Space before the button

                // Edit Profile Button at the bottom
                SizedBox(
                  width: screenWidth * 0.9, // Adjusts button width to 90% of screen width
                  child: ElevatedButton(
                    onPressed: () async {
                      // Navigate to Edit Profile and wait for result
                      bool isUpdated = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EditProfilePage(
                            userID: widget.userID,
                            userRepository: userRepository,
                          ),
                        ),
                      );

                      // If profile was updated, refresh the user data
                      if (isUpdated) {
                        refreshProfile();
                      }
                    },
                    child: Text("Edit Profile", style: AppTextStyles.buttonText(context)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.black,
                      padding: EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // Helper method to create info rows
  Widget buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text(
            "$label ",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }
}






