import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:mae_assignment/models/alert.dart';
import 'package:mae_assignment/models/reminder.dart';
import 'package:mae_assignment/providers/emergency_providers.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_AlertAndNotifications.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_healthLog.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'elderly_dashboard.dart';

String formatTimestamp(dynamic timestamp) {
  if (timestamp is Timestamp) {
    return DateFormat('yyyy-MM-dd HH').format(timestamp.toDate());
  }
  return 'Invalid date';
}

class ReminderPage extends StatelessWidget {
  final String userID;

  ReminderPage({required this.userID});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ReminderProvider(),
      child: ChangeNotifierProvider(
        create: (context) => AlertProvider(),
        child: _ReminderPageContent(userID: userID),
      ),
    );
  }
}

class _ReminderPageContent extends StatefulWidget {
  final String userID;

  _ReminderPageContent({required this.userID});

  @override
  _ReminderPageContentState createState() => _ReminderPageContentState();
}

class _ReminderPageContentState extends State<_ReminderPageContent> {
  final EmergencyService emergencyService = EmergencyService();
  int _selectedIndex = 2;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    // Navigate to the appropriate page
    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => ElderlyDashboardPage(
                  userID: widget.userID,
                )),
      );
    }

    if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) =>
                ElderlyHealthLogPage(userID: widget.userID)),
      );
    }

    if (index == 3) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => ElderlyAlertandnotifications(
                  userID: widget.userID,
                )),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    // Fetch reminders and alerts
    final reminderProvider = Provider.of<ReminderProvider>(context);
    final alertProvider = Provider.of<AlertProvider>(context);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.settings,
              color: Colors.black, size: screenWidth * 0.1),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SettingPage(
                  userID: widget.userID,
                ),
              ),
            );
          },
        ),
        title: Image.asset(
          'assets/mae emblem.png',
          height: screenWidth * 0.15,
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(
              Icons.account_circle,
              color: Colors.black,
              size: screenWidth * 0.1,
            ),
            onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProfilePage(
                          userID: widget.userID,
                        ),
                      ),
                    );            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(screenWidth * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Elderly People Reminder & Alert",
              style: GoogleFonts.lato(
                  fontSize: screenWidth * 0.06, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: screenHeight * 0.02),
            SectionWithDivider(title: "Medication Reminders"),
            StreamBuilder<List<Reminder>>(
              stream: reminderProvider.fetchReminders(widget.userID),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Text(
                      "No medication reminders available",
                      style:
                          GoogleFonts.roboto(fontSize: 16, color: Colors.grey),
                    ),
                  );
                }

                var reminders = snapshot.data!
                  ..sort((a, b) => a.datetime.compareTo(b.datetime));

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(
                        label: Container(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            'Medication Type',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ),
                      DataColumn(
                        label: Container(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            'Date & Time',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ),
                      DataColumn(
                        label: Container(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            'Status',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ),
                    ],
                    rows: reminders.map((reminder) {
                      return DataRow(cells: [
                        DataCell(Text(reminder.medicationType)),
                        DataCell(Text(formatTimestamp(reminder.datetime))),
                        DataCell(Text(reminder.reminderStatus)),
                      ]);
                    }).toList(),
                  ),
                );
              },
            ),
            SizedBox(height: screenHeight * 0.03),
            SectionWithDivider(title: "Alert History"),
            StreamBuilder<List<Alert>>(
              stream: alertProvider.fetchAlerts(widget.userID),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Text(
                      "No alert history available",
                      style:
                          GoogleFonts.roboto(fontSize: 16, color: Colors.grey),
                    ),
                  );
                }

                var alerts = snapshot.data!
                  ..sort((a, b) => a.alertTime.compareTo(b.alertTime));

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: [
                      DataColumn(
                        label: Container(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            'Alert Status',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ),
                      DataColumn(
                        label: Container(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Text(
                            'Date & Time',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16),
                          ),
                        ),
                      ),
                    ],
                    rows: alerts.map((alert) {
                      // Check if alert is due or past
                      bool isDueOrPast = alert.alertTime.toDate().isBefore(DateTime.now());
                      return DataRow(
                        color: isDueOrPast ? WidgetStateProperty.all(Colors.red[100]) : null,
                        cells: [
                          DataCell(Text(alert.alertStatus)),
                          DataCell(Text(formatTimestamp(alert.alertTime))),
                        ],
                      );
                    }).toList(),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          try {
            await emergencyService.initiateEmergency(widget.userID);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Emergency call initiated.')),
            );
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Failed to initiate emergency: $e')),
            );
          }
        },
        label: Text(
          "Emergency",
          style: TextStyle(fontSize: fontSize, color: Colors.white),
        ),
        icon: Icon(Icons.phone, color: Colors.white),
        backgroundColor: AppColors.tertiary,
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: AppColors.secondary,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home, size: screenWidth * 0.1), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.health_and_safety, size: screenWidth * 0.1),
              label: 'Health Data'),
          BottomNavigationBarItem(
              icon: Icon(Icons.alarm, size: screenWidth * 0.1),
              label: 'Reminder'),
          BottomNavigationBarItem(
              icon: Icon(Icons.notifications, size: screenWidth * 0.1),
              label: 'Alerts'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.placeholder,
        onTap: _onItemTapped,
      ),
    );
  }
}

class SectionWithDivider extends StatelessWidget {
  final String title;

  SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            title,
            style: GoogleFonts.roboto(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.placeholder),
          ),
        ),
        Divider(thickness: 1, color: AppColors.placeholder),
      ],
    );
  }
}

class ReminderProvider with ChangeNotifier {
  Stream<List<Reminder>> fetchReminders(String userID) {
    return FirebaseFirestore.instance
        .collection('reminders')
        .where('elderlyUserID',
            isEqualTo: userID) 
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) {
            try {
              return Reminder.fromFirestore(doc);
            } catch (e) {
              print('Error creating Reminder from document: $e');
              return null; // Handle this if necessary
            }
          })
          .where((reminder) => reminder != null)
          .cast<Reminder>()
          .toList();
    });
  }
}

class AlertProvider with ChangeNotifier {
  // Fetch alerts from Firestore for a specific elderly user
  Stream<List<Alert>> fetchAlerts(String userID) {
    return FirebaseFirestore.instance
        .collection('alerts') // Correct collection name for alerts
        .where('elderlyID', isEqualTo: userID) // Ensure field matches your Firestore field
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        try {
          return Alert.fromFirestore(doc); // Assuming you have fromFirestore in Alert model
        } catch (e) {
          print('Error creating Alert from document: $e');
          return null; // Handle this if necessary
        }
      }).where((alert) => alert != null).cast<Alert>().toList();
    });
  }
}