import 'package:flutter/material.dart';
import 'package:mae_assignment/providers/appointment_scheduler.dart';
import 'package:mae_assignment/repositories/appointment_repository.dart'; // Import the logic class

class AppointmentScheduler extends StatefulWidget {
  final String userID;
  final String providerID;

  AppointmentScheduler({required this.userID, required this.providerID});

  @override
  _AppointmentSchedulerState createState() => _AppointmentSchedulerState();
}

class _AppointmentSchedulerState extends State<AppointmentScheduler> {
  late AppointmentSchedulerLogic _appointmentSchedulerLogic;

  @override
  void initState() {
    super.initState();
    _appointmentSchedulerLogic = AppointmentSchedulerLogic(AppointmentRepository());
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Date Picker
        ListTile(
          title: Text(_appointmentSchedulerLogic.selectedDate == null
              ? "Pick Date"
              : "Selected Date: ${_appointmentSchedulerLogic.selectedDate!.toLocal()}".split(' ')[0]),
          trailing: Icon(Icons.calendar_today),
          onTap: () async {
            final pickedDate = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime.now(),
              lastDate: DateTime(2100),
            );
            if (pickedDate != null) {
              setState(() {
                _appointmentSchedulerLogic.setSelectedDate(pickedDate);
              });
            }
          },
        ),

        // Time Picker
        ListTile(
          title: Text(_appointmentSchedulerLogic.selectedTime == null
              ? "Pick Time"
              : "Selected Time: ${_appointmentSchedulerLogic.selectedTime!.format(context)}"),
          trailing: Icon(Icons.access_time),
          onTap: () async {
            final pickedTime = await showTimePicker(
              context: context,
              initialTime: TimeOfDay.now(),
            );
            if (pickedTime != null) {
              setState(() {
                _appointmentSchedulerLogic.setSelectedTime(pickedTime);
              });
            }
          },
        ),

        // Save Appointment Button
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton(
            onPressed: () => _appointmentSchedulerLogic.saveAppointment(context, widget.userID, widget.providerID),
            child: Text("Schedule Appointment"),
          ),
        ),
      ],
    );
  }
}
