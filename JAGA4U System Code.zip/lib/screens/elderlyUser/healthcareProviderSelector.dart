import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mae_assignment/providers/ProviderSelection.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_appointment_selector.dart';

class HealthcareProviderSelector extends StatefulWidget {
  final String userID;

  HealthcareProviderSelector({required this.userID});

  @override
  _HealthcareProviderSelectorState createState() =>
      _HealthcareProviderSelectorState();
}

class _HealthcareProviderSelectorState
    extends State<HealthcareProviderSelector> {
  String? selectedProviderID;
  List<Map<String, dynamic>> bookedAppointments = [];

  // Fetch booked appointments for the selected provider
  Future<void> fetchBookedAppointments(String providerID) async {
    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('appointments')
          .where('healthCareID', isEqualTo: providerID)
          .where('status', isEqualTo: 'scheduled')
          .get();

      setState(() {
        bookedAppointments = querySnapshot.docs.map((doc) {
          print(
              "Appointment data: ${doc.data()}"); // Log each appointment's data
          return doc.data() as Map<String, dynamic>;
        }).toList();
      });
    } catch (e) {
      print("Failed to fetch appointments: $e");
    }
  }

  void handleProviderSelection(String providerID) async {
    setState(() {
      selectedProviderID = providerID;
      bookedAppointments = [];
    });

    // Fetch booked appointments for the selected provider
    await fetchBookedAppointments(providerID);

    // Show dialog with appointment details and scheduling option
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Schedule Appointment and View Booked Appointments"),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (bookedAppointments.isEmpty)
                Text("No appointments booked.")
              else
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: bookedAppointments.map((appointment) {
                    DateTime appointmentDate =
                        (appointment['appointmentDateTime'] as Timestamp)
                            .toDate();

                    // Format date and time separately
                    String formattedDate =
                        "${appointmentDate.year}-${appointmentDate.month.toString().padLeft(2, '0')}-${appointmentDate.day.toString().padLeft(2, '0')}";
                    String formattedTime =
                        "${appointmentDate.hour.toString().padLeft(2, '0')}:${appointmentDate.minute.toString().padLeft(2, '0')}";

                    return ListTile(
                      title: Text("Date: $formattedDate"),
                      subtitle: Text("Time: $formattedTime"),
                    );
                  }).toList(),
                ),
              AppointmentScheduler(
                  userID: widget.userID, providerID: providerID),
            ],
          ),
        ),
        actions: [
          TextButton(
            child: Text("Cancel"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Healthcare Provider")),
      body: ProviderSelection(onProviderSelected: handleProviderSelection),
    );
  }
}
