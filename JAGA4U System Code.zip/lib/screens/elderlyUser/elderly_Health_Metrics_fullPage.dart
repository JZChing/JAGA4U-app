import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:mae_assignment/models/health_metrics.dart';

class FullDataPage extends StatefulWidget {
  final String elderlyID;

  FullDataPage({required this.elderlyID});

  @override
  _FullDataPageState createState() => _FullDataPageState();
}

class _FullDataPageState extends State<FullDataPage> {
  List<HealthData> bloodPressureData = [];
  List<HealthData> pulseRateData = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchHealthData();
  }

  bool _checkEmergencyStatus(double bloodPressure, double pulseRate) {
    // Check for emergency based on blood pressure and pulse rate
    if (bloodPressure > 130 ||
        bloodPressure < 90 ||
        pulseRate < 60 ||
        pulseRate > 100) {
      return true; // Set as emergency if any condition is met
    }
    return false;
  }

  Future<void> fetchHealthData() async {
    setState(() {
      isLoading = true;
    });

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('HealthMetrics')
          .where('elderlyUserID', isEqualTo: widget.elderlyID)
          .get();

      bloodPressureData = snapshot.docs.map((doc) {
        final healthMetric = HealthMetrics.fromFirestore(doc);
        double bloodPressureValue = (healthMetric.bloodPressure is int)
            ? (healthMetric.bloodPressure as int).toDouble()
            : healthMetric.bloodPressure;

        return HealthData(
          time: DateFormat('yyyy-MM-dd').format(healthMetric.dateTime.toDate()),
          value: bloodPressureValue,
        );
      }).toList();

      pulseRateData = snapshot.docs.map((doc) {
        final healthMetric = HealthMetrics.fromFirestore(doc);
        double pulseRateValue = (healthMetric.pulseRate is int)
            ? (healthMetric.pulseRate as int).toDouble()
            : healthMetric.pulseRate;

        return HealthData(
          time: DateFormat('yyyy-MM-dd').format(healthMetric.dateTime.toDate()),
          value: pulseRateValue,
        );
      }).toList();
    } catch (e) {
      print("Error fetching health data: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> addHealthData(double bloodPressure, double pulseRate) async {
    bool isEmergency = _checkEmergencyStatus(bloodPressure, pulseRate);

    String healthMetricsID =
        FirebaseFirestore.instance.collection('HealthMetrics').doc().id;

    try {
      await FirebaseFirestore.instance
          .collection('HealthMetrics')
          .doc(healthMetricsID)
          .set({
        'healthMetricsID': healthMetricsID,
        'elderlyUserID': widget.elderlyID,
        'bloodPressure': bloodPressure,
        'pulseRate': pulseRate,
        'dateTime': Timestamp.now(),
        'emergencyStatus': isEmergency,
      });

      // Append the new data locally
      final now = DateFormat('yyyy-MM-dd').format(DateTime.now());
      setState(() {
        bloodPressureData.add(HealthData(time: now, value: bloodPressure));
        pulseRateData.add(HealthData(time: now, value: pulseRate));
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Data added successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error adding data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // UI code as previously implemented, with added button to call addHealthData
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        title: Text('Graph Health Log',
            style: GoogleFonts.lato(
                color: Colors.white,
                fontSize: MediaQuery.of(context).size.width * 0.07)),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                    child: _buildChart("Blood Pressure", bloodPressureData,
                        'Blood Pressure (mmHg)')),
                SizedBox(height: 20),
                Expanded(
                    child: _buildChart(
                        "Pulse Rate", pulseRateData, 'Pulse Rate (BPM)')),
                ElevatedButton(
                  onPressed: () {
                    // Example data; replace with actual input collection logic
                    addHealthData(125.0, 75.0);
                  },
                  child: Text("Add Health Data"),
                ),
              ],
            ),
    );
  }

  Widget _buildChart(String title, List<HealthData> data, String yAxisTitle) {
    // Sort the data by time in ascending order
    data.sort((a, b) => a.time.compareTo(b.time));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        if (data.isEmpty)
          Text('No data available', style: TextStyle(color: Colors.red))
        else
          Expanded(
            child: SfCartesianChart(
              primaryXAxis: CategoryAxis(title: AxisTitle(text: 'Date')),
              primaryYAxis: NumericAxis(title: AxisTitle(text: yAxisTitle)),
              series: <CartesianSeries<HealthData, String>>[
                LineSeries<HealthData, String>(
                  dataSource: data,
                  xValueMapper: (HealthData data, _) => data.time,
                  yValueMapper: (HealthData data, _) => data.value.toDouble(),
                  markerSettings: MarkerSettings(isVisible: true),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class HealthData {
  final String time;
  final double value;

  HealthData({required this.time, required this.value});
}
