import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mae_assignment/providers/location_service.dart';
import 'package:provider/provider.dart';

class ShareLocationPage extends StatelessWidget {
  final String userID;

  ShareLocationPage({required this.userID});

  @override
  Widget build(BuildContext context) {
    return Consumer<LocationService>(
      builder: (context, locationService, child) {
        bool isSharingLocation = locationService.getIsSharingLocation();
        LatLng currentLocation = locationService.getCurrentLocation();

        return Scaffold(
          appBar: AppBar(
            title: Text('Share Location'),
            centerTitle: true,
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                CircularProgressIndicator(),
                SizedBox(height: 20),
                Text(isSharingLocation
                    ? 'Sharing location in real-time...'
                    : 'Location sharing is off'),
                SizedBox(height: 20),
                Text(
                  'Latitude: ${currentLocation.latitude}, Longitude: ${currentLocation.longitude}',
                ),
                SizedBox(height: 20),
                Container(
                  height: 300,
                  width: double.infinity,
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: currentLocation,
                      zoom: 17,
                    ),
                    myLocationEnabled: true,
                    myLocationButtonEnabled: true,
                    markers: {
                      Marker(
                        markerId: MarkerId('currentLocation'),
                        position: currentLocation,
                      ),
                    },
                  ),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    if (isSharingLocation) {
                      locationService.stopLocationSharing();
                    } else {
                      locationService.startLocationSharing(userID);
                    }
                  },
                  child: Text(isSharingLocation ? 'Stop Sharing' : 'Start Sharing'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isSharingLocation ? Colors.red : Colors.green,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}