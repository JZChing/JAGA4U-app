import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mae_assignment/models/medication.dart';
import 'package:mae_assignment/repositories/medication_repository.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MedicationTable extends StatefulWidget {
  final String userID;

  MedicationTable({required this.userID});

  @override
  _MedicationTableState createState() => _MedicationTableState();
}

class _MedicationTableState extends State<MedicationTable> {
  late Future<List<Medication>> _medicationsFuture;
  final MedicationRepository _medicationRepository = MedicationRepository();

  @override
  void initState() {
    super.initState();
    _loadMedications();
  }

  void _loadMedications() {
    _medicationsFuture = _medicationRepository.fetchMedicationsForUserToday(widget.userID);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Medication>>(
      future: _medicationsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text("Error: ${snapshot.error}"));
        }

        final medications = snapshot.data ?? [];

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: medications.isNotEmpty
                ? buildMedicationRows(context, medications)
                : [buildNoMedicationsCard()],
          ),
        );
      },
    );
  }

  List<Widget> buildMedicationRows(BuildContext context, List<Medication> medications) {
    double screenWidth = MediaQuery.of(context).size.width;
    double titleFontSize = screenWidth * 0.045;

    return medications.map((medication) {
      Color backgroundColor = medication.medicationStatus == 'completed' ? Colors.green[300]! : Colors.red[300]!;

      return Dismissible(
        key: ValueKey(medication.medicationID),
        background: Container(
          color: backgroundColor,
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Icon(
            Icons.check_circle,
            color: Colors.white,
            size: 30,
          ),
        ),
        secondaryBackground: Container(
          color: Colors.red,
          alignment: Alignment.centerRight,
          padding: EdgeInsets.symmetric(horizontal: 8.0),
          child: Icon(
            Icons.cancel,
            color: Colors.white,
            size: 30,
          ),
        ),
        onDismissed: (direction) async {
          // Batch update for both medication and reminder
          try {
            WriteBatch batch = FirebaseFirestore.instance.batch();

            // Step 1: Update medication status to 'completed'
            DocumentReference medicationRef = FirebaseFirestore.instance
                .collection('medications')
                .doc(medication.medicationID);
            batch.update(medicationRef, {'medicationStatus': 'completed'});

            // Step 2: Query reminders to find the reminder that has this medicationID
            QuerySnapshot reminderSnapshot = await FirebaseFirestore.instance
                .collection('reminders')
                .where('medicationID', isEqualTo: medication.medicationID)
                .get();

            // Step 3: If a reminder exists, update its status to 'completed'
            if (reminderSnapshot.docs.isNotEmpty) {
              // Get the first matching reminder (assuming one reminder per medication)
              DocumentReference reminderRef = reminderSnapshot.docs.first.reference;
              batch.update(reminderRef, {'reminderStatus': 'completed'});
            }

            // Commit the batch update
            await batch.commit();

            // Show confirmation snack bar
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${medication.medicationType} and reminder marked as completed')),
            );

            // Reload medications to reflect the updates
            setState(() {
              _loadMedications();
            });
          } catch (e) {
            print("Error updating medication and reminder status: $e");
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4.0),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Container(
              height: 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [backgroundColor.withOpacity(0.8), backgroundColor.withOpacity(0.5)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        medication.medicationType,
                        style: TextStyle(
                          fontSize: titleFontSize,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    VerticalDivider(thickness: 1, color: Colors.white),
                    Expanded(
                      child: Text(
                        medication.dosage,
                        style: TextStyle(
                          fontSize: titleFontSize,
                          fontWeight: FontWeight.bold,
                          color: Colors.redAccent,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    VerticalDivider(thickness: 1, color: Colors.white),
                    Expanded(
                      child: Text(
                        DateFormat('h:mm a').format(medication.dateTime),
                        style: TextStyle(
                          fontSize: titleFontSize,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }).toList();
  }

  Widget buildNoMedicationsCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Text(
            'No medications scheduled for today',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
