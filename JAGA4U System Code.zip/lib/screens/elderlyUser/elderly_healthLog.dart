import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:mae_assignment/providers/health_log_providers.dart';
import 'package:mae_assignment/screens/caregiver/reviewHealthData.dart';
import 'package:mae_assignment/screens/elderlyUser/elderly_Health_Metrics_fullPage.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/app_text_style.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/models/health_metrics.dart';
import 'package:mae_assignment/widgets/custom_elderlyBotNavBar.dart'; // Import the custom bottom nav bar

class ElderlyHealthLogPage extends StatefulWidget {
  final String userID;

  ElderlyHealthLogPage({required this.userID});

  @override
  _ElderlyHealthLogPageState createState() => _ElderlyHealthLogPageState();
}

class _ElderlyHealthLogPageState extends State<ElderlyHealthLogPage> {
  int _selectedIndex = 1;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchHealthData();
  }

  Future<void> fetchHealthData() async {
    setState(() => isLoading = true);
    try {
      await Provider.of<HealthMetricsProvider>(context, listen: false)
          .fetchHealthData(widget.userID);
      print("fetchHealthData called and completed in UI");

      final healthMetrics =
          Provider.of<HealthMetricsProvider>(context, listen: false)
              .healthMetrics;
      print("Health metrics length after fetch: ${healthMetrics.length}");
      for (var metric in healthMetrics) {
        print("Fetched health metric in UI: $metric");
      }
    } catch (e) {
      print("Error fetching health data in UI: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.secondary,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.settings,
              color: Colors.black, size: screenWidth * 0.1),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => SettingPage(
                  userID: widget.userID,
                ),
              ),
            );
          },
        ),
        title: Image.asset('assets/mae emblem.png', height: screenWidth * 0.15),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle,
                color: Colors.black, size: screenWidth * 0.1),
            onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProfilePage(userID: widget.userID))),
          ),
        ],
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Consumer<HealthMetricsProvider>(
              builder: (context, healthProvider, child) {
                return SingleChildScrollView(
                  padding: EdgeInsets.all(screenWidth * 0.04),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text("Elderly People Health Log",
                          style: GoogleFonts.lato(
                              fontSize: screenWidth * 0.06,
                              fontWeight: FontWeight.bold)),
                      SizedBox(height: screenWidth * 0.05),
                      SectionWithDivider(title: "Recent Health Metrics"),
                      buildHealthDataTable(healthProvider.healthMetrics),
                      ElevatedButton(
                        onPressed: () => _showLogDataForm(context),
                        child: Text("Log Health Data"),
                      ),
                    ],
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          try {
            await Provider.of<HealthMetricsProvider>(context, listen: false)
                .initiateEmergency(widget.userID);
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Emergency call initiated.')));
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Failed to initiate emergency: $e')));
          }
        },
        label: Text("Emergency",
            style: TextStyle(fontSize: fontSize, color: Colors.white)),
        icon: Icon(Icons.phone, color: Colors.white),
        backgroundColor: AppColors.tertiary,
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _selectedIndex,
        fontSize: fontSize,
        userID: widget.userID,
      ), // Use CustomBottomNavBar widget here
    );
  }

  Widget buildHealthDataTable(List<HealthMetrics> healthMetrics) {
    return healthMetrics.isEmpty
        ? Center(child: Text("No health data available."))
        : SingleChildScrollView(
            scrollDirection: Axis.horizontal, // Enables horizontal scrolling
            child: Column(
              children: [
                DataTable(
                  columns: [
                    DataColumn(label: Text("Time")),
                    DataColumn(label: Text("Blood Pressure")),
                    DataColumn(label: Text("Pulse Rate")),
                  ],
                  rows: healthMetrics.map((metric) {
                    return DataRow(cells: [
                      DataCell(Text(DateFormat('yyyy-MM-dd').format(
                          DateTime.fromMillisecondsSinceEpoch(
                              metric.dateTime.seconds * 1000)))),
                      DataCell(Text(metric.bloodPressure.toString())),
                      DataCell(Text(metric.pulseRate.toString())),
                    ]);
                  }).toList(),
                ),
                ViewMoreButton(onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FullDataPage(
                        elderlyID: widget.userID,
                      ),
                    ),
                  );
                }),
              ],
            ),
          );
  }

  void _showLogDataForm(BuildContext context) {
    TextEditingController bpController = TextEditingController();
    TextEditingController prController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Log Health Data"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                  controller: bpController,
                  decoration: InputDecoration(labelText: "Blood Pressure")),
              TextField(
                  controller: prController,
                  decoration: InputDecoration(labelText: "Pulse Rate")),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context), child: Text("Cancel")),
            TextButton(
              onPressed: () {
                _logAndCloseDialog(bpController.text, prController.text);
                Navigator.pop(context);
              },
              child: Text("Log"),
            ),
          ],
        );
      },
    );
  }

  void _logAndCloseDialog(String bp, String pr) async {
    await Provider.of<HealthMetricsProvider>(context, listen: false)
        .logHealthData(widget.userID, bp, pr);

    // Fetch updated data after logging
    await fetchHealthData();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Health data logged successfully")),
    );
  }
}

class SectionWithDivider extends StatelessWidget {
  final String title;

  SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: GoogleFonts.lato(
                fontSize: screenWidth * 0.05, fontWeight: FontWeight.bold)),
        Divider(thickness: 2, color: Colors.grey[300]),
        SizedBox(height: screenWidth * 0.02),
      ],
    );
  }
}
