import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/models/alert.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/widgets/custom_elderlyBotNavBar.dart';
import 'package:mae_assignment/providers/alert_providers.dart';

class ElderlyAlertandnotifications extends StatefulWidget {
  final String userID;

  ElderlyAlertandnotifications({required this.userID});

  @override
  _ElderlyAlertandnotificationsState createState() =>
      _ElderlyAlertandnotificationsState();
}

class _ElderlyAlertandnotificationsState
    extends State<ElderlyAlertandnotifications> {
  List<Alert> alerts = [];
  int _selectedIndex = 3;

  @override
  void initState() {
    super.initState();
    _fetchNotifications(); // Fetch alerts on screen load
  }

  Future<void> _fetchNotifications() async {
    List<Alert> fetchedAlerts = await AlertService.fetchAlerts(widget.userID);
    setState(() {
      alerts = fetchedAlerts;
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: _buildAppBar(screenWidth),
      body: _buildBody(screenWidth),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _selectedIndex,
        fontSize: fontSize,
        userID: widget.userID,
      ),
    );
  }

  AppBar _buildAppBar(double screenWidth) {
    return AppBar(
      backgroundColor: AppColors.secondary,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.settings, color: Colors.black, size: screenWidth * 0.08),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SettingPage(userID: widget.userID),
            ),
          );
        },
      ),
      title: Image.asset('assets/mae emblem.png', height: screenWidth * 0.15),
      centerTitle: true,
      actions: [
        IconButton(
          icon: Icon(Icons.account_circle, color: Colors.black, size: screenWidth * 0.08),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProfilePage(userID: widget.userID)),
          ),
        ),
      ],
    );
  }

  Widget _buildBody(double screenWidth) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: screenWidth * 0.05),
            Text(
              "Notifications",
              style: GoogleFonts.roboto(
                fontSize: screenWidth * 0.07,
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
              ),
            ),
            SizedBox(height: screenWidth * 0.05),
            if (alerts.isEmpty) _buildEmptyState(screenWidth) else _buildNotificationList(screenWidth),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(double screenWidth) {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: screenWidth * 0.1),
        child: Text(
          "No alerts for this user.",
          style: GoogleFonts.roboto(
            fontSize: screenWidth * 0.05,
            color: AppColors.placeholder,
          ),
        ),
      ),
    );
  }

  Widget _buildNotificationList(double screenWidth) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: alerts.length,
      itemBuilder: (context, index) {
        Alert alert = alerts[index];

        return Padding(
          padding: EdgeInsets.only(bottom: screenWidth * 0.03),
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(screenWidth * 0.03),
            ),
            elevation: 3,
            color: alert.alertStatus.contains('expired') ? Colors.red.shade50 : Colors.white,
            child: ListTile(
              leading: Icon(
                Icons.warning,
                color: alert.alertStatus.contains('expired') ? Colors.red : AppColors.primary,
                size: screenWidth * 0.08,
              ),
              title: Text(
                alert.alertStatus,
                style: GoogleFonts.roboto(
                  fontSize: screenWidth * 0.05,
                  fontWeight: FontWeight.bold,
                  color: alert.alertStatus.contains('expired') ? Colors.red : Colors.blueGrey,
                ),
              ),
              subtitle: Text(
                'Date: ${alert.alertTime.toDate()}',
                style: GoogleFonts.roboto(
                  fontSize: screenWidth * 0.04,
                  color: alert.alertStatus.contains('expired') ? Colors.red : Colors.blueGrey,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
