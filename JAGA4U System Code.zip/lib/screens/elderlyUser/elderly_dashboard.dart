import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mae_assignment/providers/emergency_providers.dart';
import 'package:mae_assignment/screens/elderlyUser/today_medication_table_providers.dart';
import 'package:mae_assignment/screens/elderlyUser/healthcareProviderSelector.dart';
import 'package:mae_assignment/screens/elderlyUser/shareLocation.dart';
import 'package:mae_assignment/screens/login.dart';
import 'package:mae_assignment/screens/profile.dart';
import 'package:mae_assignment/screens/setting.dart';
import 'package:provider/provider.dart';
import 'package:mae_assignment/theme_provider.dart';
import 'package:mae_assignment/widgets/custom_appBar.dart';
import 'package:mae_assignment/theming/custom_themes.dart';
import 'package:mae_assignment/widgets/custom_elderlyBotNavBar.dart'; 

class ElderlyDashboardPage extends StatefulWidget {
  final String userID;

  ElderlyDashboardPage({required this.userID});

  @override
  _ElderlyDashboardPageState createState() => _ElderlyDashboardPageState();
}

class _ElderlyDashboardPageState extends State<ElderlyDashboardPage> {
  int _selectedIndex = 0;
  final EmergencyService emergencyService = EmergencyService();

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    double iconSize = screenWidth * 0.1;

    // Access the font size from the provider
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Scaffold(
      appBar: CustomAppBar(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(screenWidth * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Elderly Dashboard",
              style: GoogleFonts.lato(
                  fontSize: fontSize, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: screenHeight * 0.02),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: Icon(Icons.account_circle,
                      color: Colors.black, size: iconSize),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ProfilePage(
                          userID: widget.userID,
                        ),
                      ),
                    );
                  },
                ),
                IconButton(
                  icon:
                      Icon(Icons.settings, color: Colors.black, size: iconSize),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SettingPage(
                                userID: widget.userID,
                              )),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.calendar_month,
                      color: Colors.black, size: iconSize),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => HealthcareProviderSelector(
                              userID: widget.userID)),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.location_on,
                      color: Colors.blue, size: iconSize),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ShareLocationPage(userID: widget.userID)),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(Icons.logout, color: Colors.black, size: iconSize),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginPage(),
                      ),
                    );
                  },
                ),
              ],
            ),
            SizedBox(height: screenHeight * 0.02),
            SectionWithDivider(title: "Today's Medication Schedule"),
            MedicationTable(userID: widget.userID),
          ],
        ),
      ),
      floatingActionButton: Stack(
        children: [
          Positioned(
            bottom: 20,
            right: 20,
            child: FloatingActionButton.extended(
              onPressed: () async {
                try {
                  await emergencyService.initiateEmergency(widget.userID);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Emergency call initiated.')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Failed to initiate emergency: $e')),
                  );
                }
              },
              label: Text(
                "Emergency",
                style: TextStyle(fontSize: fontSize, color: Colors.white),
              ),
              icon: Icon(Icons.phone, color: Colors.white),
              backgroundColor: AppColors.tertiary,
            ),
          ),
        ],
      ),
      // Use the new CustomBottomNavBar widget
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _selectedIndex,
        fontSize: fontSize,
        userID: widget.userID,  // Pass userID here
      ),
    );
  }
}

class SectionWithDivider extends StatelessWidget {
  final String title;

  SectionWithDivider({required this.title});

  @override
  Widget build(BuildContext context) {
    double fontSize = Provider.of<ThemeProvider>(context).fontSize;

    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            title,
            style: GoogleFonts.roboto(
                fontSize: fontSize * 0.9,
                fontWeight: FontWeight.bold,
                color: AppColors.placeholder),
          ),
        ),
        Divider(thickness: 1, color: AppColors.placeholder),
      ],
    );
  }
}
