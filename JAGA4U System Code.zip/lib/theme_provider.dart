import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  double _fontSize = 16.0; // Default font size
  bool _isDarkMode = false;

  double get fontSize => _fontSize;
  ThemeData get themeData => _buildThemeData();

  void toggleTheme(bool isDarkMode) {
    _isDarkMode = isDarkMode;
    notifyListeners();
  }

  void setFontSize(double newSize) {
    _fontSize = newSize;
    notifyListeners();
  }

  ThemeData _buildThemeData() {
    return ThemeData(
      brightness: _isDarkMode ? Brightness.dark : Brightness.light,
      primaryColor: Colors.blue,
      textTheme: TextTheme(
        bodyLarge: TextStyle(fontSize: _fontSize),
        bodyMedium: TextStyle(fontSize: _fontSize - 2),
        displayLarge: TextStyle(fontSize: _fontSize + 10, fontWeight: FontWeight.bold),
        titleLarge: TextStyle(fontSize: _fontSize + 4),
      ),
    );
  }
}
